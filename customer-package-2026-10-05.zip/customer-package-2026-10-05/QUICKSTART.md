# Quick Start — Installation in 10 Steps

The full detail is in the Word guide. This is the short version for someone who
has done a Power Platform install before.

**Install in this order.** Out of order fails with errors that point at the
wrong thing.

---

## Azure

**1. Run the installer.**

```powershell
cd 1-Azure
.\Install-Azure.ps1
```

Supply your subscription, an **existing** resource group, and your Power
Platform environment URL. Note the Function hostname it prints.

**2. Check it is protected.**

```powershell
Invoke-WebRequest -Uri "https://<function-host>/api/convert" -Method POST -Body '{}' -ContentType 'application/json'
```

Expect **401**. If you get 404 the app did not start. If you get 200, stop.

**3. Copy the Function key.** Azure portal → Function app → **App keys** →
default host key.

---

## Connector

**4. Import the connector.** make.powerapps.com → **Solutions** → **Import** →
`2-Connector\SalesOrderMarkItDownConnector_1.0.1.1_managed.zip` (managed).

**5. Create one connection.** **Connections** → **+ New connection** → *Sales
Order MarkItDown Converter*. Enter:

| Dialog label | Value |
|---|---|
| **Function host** | the hostname from `YOUR-VALUES.md`, no `https://`, no trailing slash |
| **Function key** | the default host key from step 3 |

Confirm **Connected**. Create only one.

> **Connected** only means the record was stored. It does not prove the host or
> key work — step 10 does that.

---

## Main solution

**6. Import the main solution.** **Solutions** → **Import** →
`3-PowerPlatform\SalesOrderAgentProcessingTemplateV12_1.0.4.0_managed.zip`
(managed). This import takes several minutes; let it finish.

**7. Bind all ten connection references.** In the solution →
**Connection references**.

Bind **MarkItDown Converter (Function Key)** to the connection from step 5,
plus the Dataverse, Office 365 Outlook, Agent, Copilot Studio and Finance and
Operations references. Several Dataverse references may share one physical
connection.

> If **Next** stays greyed out during import, one reference is still unbound —
> look for the red icon.

The connector's internal API name differs between environments, and that is
normal. If a Connector field is blank, the usual cause is that the main
solution was imported before the connector; see
`KNOWN-ISSUES-AND-FIXES.md` item 1.

**8. Create the application user.** PPAC → your environment → **Settings** →
**Users + permissions** → **Application users** → **+ New app user** → add the
app using the **Managed identity client ID** from `YOUR-VALUES.md` → assign
**only** the `Sales Order MarkItDown Converter` role.

**9. Set the environment variables.** In the imported solution. Three have no
default and must be set; the rest ship with usable defaults.

| Variable | Example | Note |
|---|---|---|
| `aipod_CompanyCode` | `usmf` | Required, no default |
| `aipod_MailboxToMonitor` | `orders@contoso.com` | Personal intake, no default |
| `aipod_MailboxFolderToMonitor` | `Inbox` | Default `Inbox` |
| `aipod_SharedMailboxToMonitor` | `sales@contoso.com` | Shared intake, no default |
| `aipod_SharedMailboxFolderToMonitor` | `Inbox/SCMOrders` | Default `Inbox/SCMOrders` |
| `aipod_ProcessImagesAttachments` | `no` | Default `no` |
| `aipod_ReviewerEmailAddress` | `reviewer@contoso.com` | Needed for failure emails |

Set either the personal pair or the shared pair, not necessarily both.

**10. Publish the agent, turn on the supporting flows, then check readiness.**

Copilot Studio → publish the agent.

In the solution → **Cloud flows**, turn **on**:
`Sales Order Document Parsing - Process Ready Staging Documen`,
`WhenStatusChanges`,
`get_staging_document_file_content`,
`get_staging_document_file_content_native`,
`LoadSalesOrderData`, `Update Processing Status to Valid`.

Leave the two **email intake** flows off.

Then, from the package root:

```powershell
.\Test-Readiness.ps1 `
    -PowerPlatformEnvironmentUrl "https://<your-env>.crm.dynamics.com" `
    -FunctionHost "azfn1234.azurewebsites.net" `
    -FunctionKey (Read-Host "Function key" -AsSecureString)
```

Fix every **FAIL**. A working Function key reports HTTP 400
`MissingStagingDocumentId`, which is a pass.

**11. Test one document before switching anything on.**

Process **one** document and confirm in Dataverse:

- the staging row reached a terminal status and `aipod_extracteddata` has JSON
- the order header shows the right customer and line count
- every line has a **Line Number** and an ERP product code
- the order in Finance and Operations has the **same line count and quantities**

Only then turn on the automatic flows. They ship stopped on purpose.

---

## If something goes wrong

| Symptom | Likely cause |
|---|---|
| Function returns 404 | Deployed without a remote build — redeploy |
| "The connections could not be loaded" | Connector not imported first |
| Connector field blank on a reference | API name mismatch — known issue 1 |
| Scanned PDFs and email bodies fail, digital PDFs work | Native tool flow lost `filecontent` — known issue 2, run `scripts\Repair-NativeFileTool.ps1 -Repair` |
| Everything "succeeds" but ERP is wrong | Compare the numbers — known issue 6 |

Full explanations are in `KNOWN-ISSUES-AND-FIXES.md`.
