# Frequently Asked Questions

---

## Installation

**Do I have to install the three units in order?**
Yes. Azure must exist before the connector connection can be created, and the
connector must exist before the main solution imports, because the solution
contains connection references that point at it. Importing the main solution
first produces *"The connections could not be loaded."*

**Can I import both solutions at once?**
No. Power Platform must register a solution-aware custom connector before it
can import connection references that use it.

**The connector got a different API name in my environment. Is that a problem?**
No, that is expected. Every environment assigns its own internal API name.
Because the connector is imported first, Power Platform points the main
solution's connection references at your copy during import.

**How long does the main solution import take?**
Several minutes. It contains 11 flows, an agent, tables and business skills.
Let it finish rather than retrying, and never start a second import while one
is running.

**Why is PowerShell used for Azure but not for Power Platform?**
Deliberate. When everything ran in one script, a single failure made the whole
deployment look broken and it was hard to tell which platform was at fault.
Azure is automated; Power Platform is manual and observable.

**Can I re-run the Azure installer?**
Yes. Resource names are derived deterministically, so a second run updates the
same resources rather than creating duplicates.

**Does the installer create the resource group?**
No. It must already exist. This avoids creating resources in an unintended
place.

**What Azure permissions do I need?**
Contributor **and** User Access Administrator on the resource group. Contributor
alone cannot create the role assignments, and the failure appears only at the
end of an otherwise successful run.

---

## Connections and security

**Where is the Function key stored?**
Only inside the Power Platform connection. The installer never writes it to
disk, logs, or any file in this package.

**Why is App Service Authentication disabled?**
Admission is handled by the Function key carried in the connection. An
unauthenticated call must return **401**.

**Should I create more than one connection to the connector?**
No. Create exactly one. Duplicates make connection-reference binding ambiguous
and cause confusing behaviour after upgrades.

**Why does the Function need a Dataverse application user?**
It writes extraction results back to Dataverse as its managed identity.
Dataverse rejects the identity until an application user exists for it.

**Why only one security role?**
The converter needs the staging tables and nothing else. Assigning System
Administrator would pass a later security review far less comfortably.

---

## Configuration

**Why are all the environment variables empty?**
The package intentionally ships definitions without values, so importing cannot
overwrite your configuration, and so no values from the build environment
travel with the package.

**What happens if I leave one blank?**
The flow that needs it stops at run time. Set all five.

**Does `aipod_CompanyCode` need to match Finance and Operations exactly?**
Yes. Use the legal entity code exactly as F&O shows it.

---

## Running it

**Why do the flows ship switched off?**
So that the first failure arrives as one inspectable record rather than a
stream of partially processed ones. Turn them on after the single-document test
passes.

**Which document types are supported?**
PDF (digital and scanned), Word, Excel, HTML, plain text, and common image
formats. Plain-text email bodies are supported.

**How are scanned PDFs handled?**
Through a native document-understanding pass that performs OCR, rather than
text conversion.

**Is there a size limit?**
20 MiB per document, and one million characters of converted text.

**How long does a document take?**
Small documents typically complete in one to three minutes end to end. Most of
that is agent reasoning, not conversion.

**What happens to a document that cannot be parsed?**
The row is marked failed with a stable error code, and `SOA - Parsing Notify`
emails the reviewer address. Successful documents send nothing.

---

## Verification and trust

**The connector action succeeded. Is the document processed?**
Not necessarily. Connector success means the call was accepted. Always confirm
the Dataverse row reached a terminal status and that `aipod_extracteddata`
contains JSON.

**The agent said the order was created and verified. Is that enough?**
No. The agent's summary is a claim, not evidence. Compare the line count and
quantities in F&O against Dataverse directly.

**What should I check after processing one document?**
Four things: the staging row is terminal with JSON persisted; the header shows
the right customer and line count; every line has a Line Number and an ERP
product code; and the F&O order matches Dataverse on line count and quantities.

**Why does the guide keep saying to run the test more than once?**
Because the extraction and validation steps are AI-driven, results on the same
document can vary between runs. Run your acceptance test on several
representative documents, and more than once, before going live.

---

## Limits and known behaviour

**Are large orders supported?**
Orders of roughly 100 lines or more are the least settled area. Line extraction
and numbering are correct, but product validation may not resolve every line on
a very large order. When that happens the order is **not** created in ERP and
the header goes to Manual Review. Pilot with smaller orders and check large
ones line by line.

**Scanned PDFs and email bodies stopped working after I published the agent.**
Known issue 2. The native file tool can lose the property that carries the
document. Run `scripts\Repair-NativeFileTool.ps1 -Repair`, then re-test.

**The Connector field on a connection reference is blank.**
Known issue 1. The usual cause is importing the main solution before the
connector. The connector's internal API name differs between environments by
design; importing the connector first lets Power Platform resolve the reference
to your copy. Remove the main solution, confirm the connector solution is
installed, and import again in order.

**Calling the Function returns 404.**
The Python application was deployed without a remote build, so its dependencies
were never installed. Redeploy; the supplied installer does this correctly.

---

## Upgrades and support

**How do I upgrade later?**
Import the newer managed solutions in the same order. Environment variable
values and connections are preserved because the package ships no values.

**Can I customise the solution?**
It is managed, so customise through supported extension points. Editing
managed components directly, especially flow definitions, makes later upgrades
unreliable.

**What should I collect before raising an issue?**
The Dataverse staging row ID, its processing status, error code and message,
the related flow run ID, and whether a digital PDF succeeds while a scanned PDF
or email body fails. That last comparison alone identifies the most common
fault.
