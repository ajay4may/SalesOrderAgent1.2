# Unit 3 — Install the Main Solution

Do this **only after** Unit 1 (Azure) and Unit 2 (connector and connection) are
complete.

---

## Before you import

The main solution references the custom connector by an internal API name, and
**your environment assigns the connector a different API name** from the one
recorded in the source environment. That is expected and needs no action.

Importing the connector **first** is what makes it work: Power Platform points
the main solution's connection references at your own copy of the connector
during import. If the main solution is imported first there is nothing to
resolve against, and the Connector field is left blank and disabled.

---

## Step 1 — Import the main solution

1. Go to `https://make.powerapps.com`
2. Confirm the **environment picker** shows the correct environment
3. Left navigation → **Solutions**
4. Command bar → **Import solution**
5. **Browse** → `3-PowerPlatform\SalesOrderAgentProcessingTemplateV12_1.0.4.0_managed.zip`
6. Choose **Next**
7. Confirm it shows **Sales Order Agent Processing Template V1.2**, version
   **1.0.4.0**, **managed**
8. If a connection mapping panel appears, you may map connections now or leave
   them for Step 2. Leaving them is fine.
9. If offered, do **not** select an option that activates processes
10. Choose **Import**
11. Wait. The solution contains 11 flows, an agent, tables and business skills,
    so several minutes is normal. Do not start a second import while one is
    running.

The automatic flows ship **stopped on purpose**. Leave them stopped until
Step 8 passes.

---

## Step 2 — Bind the connection references

Power Apps → **Solutions** → open the imported solution → **Connection
references** in the left object list.

You will see **10** connection references. **All ten must be bound.**

### Bind all ten

| Display name | What to connect it to |
|---|---|
| **MarkItDown Converter (Function Key)** | The MarkItDown connection you created in Unit 2 |
| **Microsoft Dataverse SalesOrderProcessingAutomation-02e02** | A Dataverse connection |
| **Microsoft Dataverse SalesOrderProcessingAutomation-294c8** | A Dataverse connection |
| **Sales Order Document Parsing - Dataverse** | A Dataverse connection |
| **aipod_salesOrderAgent.shared_commondataserviceforapps…** | A Dataverse connection |
| **aipod_salesorderagentv1.2…shared_commondataser…** | A Dataverse connection (the agent's Dataverse tool) |
| **aipod_salesorderagentv1.2…shared_dynamicsax…** | A Finance and Operations connection (the agent's ERP tool) |
| **Office 365 Outlook** | The mailbox that receives sales orders |
| **Agent** | The agent connection, created when prompted |
| **Microsoft Copilot Studio Cre0948-db931** | A Copilot Studio connection |

The several Dataverse references may all point at the **same** physical
Dataverse connection. That is normal and is not a mistake.

> If the **Next** button stays greyed out, one reference still has no
> connection. Look for the red icon in the list and bind that one.

### How to bind one reference

1. Select the connection reference to open it
2. In the **Connection** field, choose an existing connection from the list
3. If the connector you need has no connection yet, choose **+ New connection**,
   complete the sign-in, then return and select it
4. **Save**
5. Repeat for each of the ten

---

## Step 3 — Create the Dataverse application user

The Azure Function talks to Dataverse as its managed identity. Dataverse
rejects it until that identity exists as an application user.

1. Open `YOUR-VALUES.md` and find **Managed identity client ID**
2. Go to `https://admin.powerplatform.microsoft.com`
3. **Manage** → **Environments** → select your environment
4. **Settings** → **Users + permissions** → **Application users**
5. **First check whether one already exists** for that client ID. If it does,
   skip to step 9 and check its role. Creating a second one for the same
   identity causes confusing permission behaviour.
6. Choose **+ New app user**
7. Choose **+ Add an app**, paste the **client ID**, choose **Add**
8. Choose a **business unit**, then **Create**
9. Select the app user → **Edit security roles**
10. Assign **only** the role **Sales Order MarkItDown Converter**
11. **Save**

> Do not assign System Administrator. If the role is not in the list, the main
> solution did not import correctly — the role ships inside it.

---

## Step 4 — Set the environment variables

Power Apps → **Solutions** → the imported solution → **Environment variables**.

The package ships **definitions with no values**, so importing can never
overwrite your configuration.

Open each one, enter a **Current value**, and **Save**.

| Variable | Required? | Example | Meaning |
|---|---|---|---|
| `aipod_CompanyCode` | **Yes** | `usmf` | Finance and Operations legal entity. Case matters downstream — use it exactly as F&O shows it. |
| `aipod_MailboxToMonitor` | Personal intake | `orders@contoso.com` | Mailbox watched by the personal-mailbox intake flow |
| `aipod_MailboxFolderToMonitor` | Personal intake | `Inbox` | Folder within that mailbox. Ships with default `Inbox`. |
| `aipod_SharedMailboxToMonitor` | Shared intake | `sales@contoso.com` | Mailbox watched by the shared-mailbox intake flow |
| `aipod_SharedMailboxFolderToMonitor` | Shared intake | `Inbox/SCMOrders` | Folder within the shared mailbox. Ships with that default. |
| `aipod_ProcessImagesAttachments` | **Yes** | `no` | Whether image attachments are processed. Ships with default `no`. |
| `aipod_ReviewerEmailAddress` | If using notifications | `reviewer@contoso.com` | Recipient of parsing-failure notifications |

**You do not need both intake paths.** Choose one:

- **Personal mailbox intake** — set `aipod_MailboxToMonitor` and
  `aipod_MailboxFolderToMonitor`.
- **Shared mailbox intake** — set `aipod_SharedMailboxToMonitor` and
  `aipod_SharedMailboxFolderToMonitor`, and bind the Copilot Studio connection
  reference in Step 2.

A variable that a running flow needs but that has no value will stop that flow
at run time. Variables shipped with a default are already usable; the three
with no default must be set.

---

## Step 5 — Configure the agent (Copilot Studio)

1. Go to `https://copilotstudio.microsoft.com`
2. Confirm the environment picker
3. Open the **Sales Order Agent V1.2** agent
4. Confirm its tools and knowledge sources resolved after import
5. Choose **Publish**

> After publishing, re-run the verification in Step 8. Publishing can alter an
> agent-owned flow, and the symptom is that scanned PDFs and plain-text email
> bodies stop extracting while digital PDFs keep working. See
> `KNOWN-ISSUES-AND-FIXES.md` item 2.

---

## Step 6 — Turn on the supporting flows

A managed import can leave flows switched off. The three **automatic** flows
must stay off for now, but the flows that do the actual work must be **on**, or
nothing will process.

Power Apps → **Solutions** → the imported solution → **Cloud flows**.

Turn on each of these:

| Flow | Why it is needed |
|---|---|
| `Sales Order Document Parsing - Process Ready Staging Documen` | **Picks up a document once its status becomes Ready.** Nothing processes without it, including the manual test in Step 8. |
| `WhenStatusChanges` | Drives the agent when a record's status changes |
| `get_staging_document_file_content` | Fetches the document for conversion |
| `get_staging_document_file_content_native` | Fetches scanned PDFs and email bodies |
| `LoadSalesOrderData` | Writes the extracted header and lines to Dataverse |
| `Update Processing Status to Valid` | Marks validated lines |

To turn one on: select the flow, then choose **Turn on** on the command bar.

These are optional and can be left off for now:

| Flow | Purpose |
|---|---|
| `Reprocess the not processed order lines` | Manual reprocessing helper |
| `SOA V3 - Notify` | Additional notifications |
| `SOA - Parsing Notify` | Emails the reviewer when parsing fails |

**Leave only the two email intake flows off until Step 8 passes:**

- `When sales order email with attachment arrives`
- `When a new email with attachment arrives in a shared mailbox (V2)`

These are the flows that pull mail in. Leaving them off means you control
exactly which document is processed during acceptance.

---

## Step 7 — Run the readiness check

From the package root:

```powershell
.\Test-Readiness.ps1 `
    -PowerPlatformEnvironmentUrl "https://<your-env>.crm.dynamics.com" `
    -FunctionHost "azfn1234.azurewebsites.net" `
    -FunctionKey (Read-Host "Function key" -AsSecureString)
```

Add `-SharedMailboxIntake` if you chose the shared-mailbox path.

It reports each check as `PASS`, `FAIL`, `WARN`, `UNKNOWN` or `SKIPPED`.

- Fix every **FAIL** before continuing.
- **UNKNOWN** is not a pass — it means the check could not run, usually a
  permission or a timing issue. Rerun after a minute.
- **SKIPPED** against the two unused connection references is correct.

The check that matters most is **Keyed call accepted**. A working key returns
HTTP 400 `MissingStagingDocumentId`, which proves the hostname, the key and the
deployed code without processing anything.

---

## Step 8 — Process one document before enabling anything

1. Create one staging document row manually, or turn the intake flow on
   **briefly** and drop one email into the monitored folder
2. Wait for processing to finish
3. On the `aipod_stagingdocument` row confirm:
   - `aipod_processingstatus` reached a terminal value
   - `aipod_extracteddata` contains JSON
   - `aipod_sourceorderedrowcount` matches the document's line count
4. On `aipod_salesorderheader` confirm the customer resolved and the line count
   matches
5. On `aipod_salesorderline` confirm every line has a **Line Number** and an ERP
   product code
6. In Finance and Operations, open the created sales order and confirm the
   **line count and quantities match Dataverse exactly**

> Check 6 is not optional. A connector reporting success, and the agent's own
> summary, are claims rather than evidence. Compare the actual numbers.

Only when all six pass, turn on the automatic flows.

---

## Step 9 — Turn on the automatic flows

Power Apps → **Solutions** → the imported solution → **Cloud flows**.

Turn on only the intake path you configured:

| Flow | Turn on when |
|---|---|
| `When sales order email with attachment arrives` | Using personal mailbox intake |
| `When a new email with attachment arrives in a shared mailbox (V2)` | Using shared mailbox intake |

Leave the other intake flow off. Running both means the same order can be
processed twice.

`WhenStatusChanges` and the other supporting flows were already turned on in
Step 6 and should stay on.

---

## Step 10 — Optional: failure notifications

`SOA - Parsing Notify` emails `aipod_ReviewerEmailAddress` when a document
fails to parse. It deliberately sends nothing on success. Turn it on once
`aipod_ReviewerEmailAddress` is set.
