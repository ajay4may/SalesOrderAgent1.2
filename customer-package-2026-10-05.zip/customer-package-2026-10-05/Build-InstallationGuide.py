"""Build the customer installation guide as a Word document.

The Markdown files in the package remain the maintainable source. This script
renders them into one ordered, navigable document for customer administrators,
who asked for something they can review, circulate and retain as installation
evidence.

Run after any change to README.md, 1-Azure/AZURE-RESOURCES.md,
3-PowerPlatform/PPAC-INSTALL.md or KNOWN-ISSUES-AND-FIXES.md.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.shared import Pt, RGBColor

PACKAGE = Path(__file__).resolve().parent
OUTPUT = PACKAGE / "Sales-Order-Document-Parsing-Installation-Guide.docx"

SECTIONS = [
    ("Quick Start", PACKAGE / "QUICKSTART.md"),
    ("Overview and Install Order", PACKAGE / "README.md"),
    ("Unit 1 — Azure Resources", PACKAGE / "1-Azure" / "AZURE-RESOURCES.md"),
    ("Unit 2 — Connector and Connection", PACKAGE / "2-Connector" / "CONNECTOR-IMPORT.md"),
    ("Unit 3 — Power Platform Installation", PACKAGE / "3-PowerPlatform" / "PPAC-INSTALL.md"),
    ("Known Issues and Fixes", PACKAGE / "KNOWN-ISSUES-AND-FIXES.md"),
    ("Frequently Asked Questions", PACKAGE / "FAQ.md"),
]

INLINE = re.compile(r"(\*\*.+?\*\*|`[^`]+`)")


def add_runs(paragraph, text: str) -> None:
    """Render bold and inline code, leaving other markup as plain text."""
    for part in INLINE.split(text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**"):
            paragraph.add_run(part[2:-2]).bold = True
        elif part.startswith("`") and part.endswith("`"):
            run = paragraph.add_run(part[1:-1])
            run.font.name = "Consolas"
            run.font.size = Pt(9.5)
        else:
            paragraph.add_run(part)


def add_table(document, rows: list[str]) -> None:
    parsed = [[c.strip() for c in r.strip().strip("|").split("|")] for r in rows]
    parsed = [r for r in parsed if not all(set(c) <= set("-: ") for c in r)]
    if not parsed:
        return
    width = max(len(r) for r in parsed)
    table = document.add_table(rows=0, cols=width)
    table.style = "Light Grid Accent 1"
    for index, cells in enumerate(parsed):
        row = table.add_row().cells
        for position in range(width):
            value = cells[position] if position < len(cells) else ""
            paragraph = row[position].paragraphs[0]
            add_runs(paragraph, value)
            if index == 0:
                for run in paragraph.runs:
                    run.bold = True
    document.add_paragraph()


def add_code(document, lines: list[str]) -> None:
    paragraph = document.add_paragraph()
    paragraph.paragraph_format.left_indent = Pt(18)
    paragraph.paragraph_format.space_after = Pt(10)
    run = paragraph.add_run("\n".join(lines))
    run.font.name = "Consolas"
    run.font.size = Pt(9)


def render(document, markdown: str, base_level: int) -> None:
    lines = markdown.splitlines()
    index = 0
    while index < len(lines):
        line = lines[index]
        stripped = line.strip()

        if stripped.startswith("```"):
            block = []
            index += 1
            while index < len(lines) and not lines[index].strip().startswith("```"):
                block.append(lines[index])
                index += 1
            add_code(document, block)
            index += 1
            continue

        if stripped.startswith("|"):
            block = []
            while index < len(lines) and lines[index].strip().startswith("|"):
                block.append(lines[index])
                index += 1
            add_table(document, block)
            continue

        if not stripped or stripped == "---":
            index += 1
            continue

        if stripped.startswith("#"):
            hashes = len(stripped) - len(stripped.lstrip("#"))
            text = stripped[hashes:].strip()
            document.add_heading(text, level=min(base_level + hashes - 1, 4))
            index += 1
            continue

        if stripped.startswith(">"):
            paragraph = document.add_paragraph()
            paragraph.paragraph_format.left_indent = Pt(18)
            add_runs(paragraph, stripped.lstrip("> ").strip())
            for run in paragraph.runs:
                run.italic = True
                run.font.color.rgb = RGBColor(0x44, 0x44, 0x44)
            index += 1
            continue

        if re.match(r"^[-*] ", stripped):
            paragraph = document.add_paragraph(style="List Bullet")
            add_runs(paragraph, stripped[2:].strip())
            index += 1
            continue

        if re.match(r"^\d+\. ", stripped):
            paragraph = document.add_paragraph(style="List Number")
            add_runs(paragraph, re.sub(r"^\d+\.\s*", "", stripped))
            index += 1
            continue

        paragraph = document.add_paragraph()
        add_runs(paragraph, stripped)
        index += 1


def build() -> Path:
    document = Document()
    normal = document.styles["Normal"]
    normal.font.name = "Segoe UI"
    normal.font.size = Pt(10.5)

    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("Sales Order Document Parsing")
    run.bold = True
    run.font.size = Pt(26)

    subtitle = document.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = subtitle.add_run("Installation Guide")
    run.font.size = Pt(16)
    run.font.color.rgb = RGBColor(0x44, 0x44, 0x44)

    meta = document.add_paragraph()
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = meta.add_run("Package version 1.0.1.0")
    run.font.size = Pt(11)

    document.add_paragraph()
    notice = document.add_paragraph()
    notice.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = notice.add_run(
        "Install the three units in order. Each registers something the next one "
        "needs, and installing out of order produces errors that do not point at "
        "the real cause."
    )
    run.bold = True

    document.add_paragraph()
    contents = document.add_paragraph()
    run = contents.add_run("Contents")
    run.bold = True
    run.font.size = Pt(13)
    for position, (heading, _) in enumerate(SECTIONS, start=1):
        document.add_paragraph(f"{position}.  {heading}", style="List Bullet")

    for heading, path in SECTIONS:
        document.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
        document.add_heading(heading, level=1)
        if not path.exists():
            raise FileNotFoundError(f"Guide source missing: {path}")
        text = path.read_text(encoding="utf-8")
        text = re.sub(r"^#\s+.*\n", "", text, count=1)
        render(document, text, base_level=2)

    document.save(OUTPUT)
    return OUTPUT


if __name__ == "__main__":
    try:
        written = build()
    except (OSError, FileNotFoundError) as error:
        print(f"Guide generation failed: {error}", file=sys.stderr)
        raise SystemExit(1) from error
    print(f"{written}  {written.stat().st_size:,} bytes")
