<#
.SYNOPSIS
    Checks whether a Sales Order Document Parsing installation is ready to
    process a document.

.DESCRIPTION
    Run this after Unit 3. It inspects the installed solutions, the connection
    references, the application user, the environment variables and the flow
    states, and - when you supply a Function key - calls the Azure Function on
    its real keyed path.

    Every result is one of:

        PASS      the check succeeded
        FAIL      the check failed and will stop processing
        WARN      worth knowing, will not stop processing on its own
        UNKNOWN   could not be determined, usually a permission or timing issue
        SKIPPED   not applicable, or an optional input was not supplied

    UNKNOWN is not a pass. It means the check could not be performed.

    No check in this script writes to Dataverse, and the Function probe is
    deliberately one that the Function rejects before it reads any document.

.PARAMETER PowerPlatformEnvironmentUrl
    For example https://contoso.crm.dynamics.com

.PARAMETER FunctionHost
    The Function hostname, for example azfn1234.azurewebsites.net.
    Without this the Function checks are skipped.

.PARAMETER FunctionKey
    The Function host key. Without this, only the unauthenticated 401 check
    runs and the keyed check is skipped. The key is never written to disk.

.PARAMETER IdentityClientId
    The Function's managed identity client ID, from YOUR-VALUES.md. Without it
    the application user checks are skipped.

.PARAMETER SharedMailboxIntake
    Include this if you use the shared-mailbox intake flow. It makes the shared
    mailbox variables and the Copilot Studio connection required instead of
    optional.

.EXAMPLE
    .\Test-Readiness.ps1 -PowerPlatformEnvironmentUrl "https://contoso.crm.dynamics.com"

.EXAMPLE
    .\Test-Readiness.ps1 -PowerPlatformEnvironmentUrl "https://contoso.crm.dynamics.com" `
                         -FunctionHost "azfn1234.azurewebsites.net" -FunctionKey (Read-Host -AsSecureString)
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string] $PowerPlatformEnvironmentUrl,

    [Parameter()]
    [string] $FunctionHost,

    [Parameter()]
    [securestring] $FunctionKey,

    [Parameter()]
    [string] $IdentityClientId,

    [Parameter()]
    [switch] $SharedMailboxIntake
)

$ErrorActionPreference = "Stop"

# ---------------------------------------------------------------------------
# Expected topology.
#
# Derived from the shipped solution by listing every connection reference and
# finding its consumers in the workflow definitions and the agent components.
# The script compares the installed set against this and reports drift, so a
# different package version is visible rather than silently mis-scored.
# ---------------------------------------------------------------------------

$ExpectedSolutions = @(
    [pscustomobject]@{ UniqueName = "SalesOrderMarkItDownConnector";        Version = "1.0.1.1" }
    [pscustomobject]@{ UniqueName = "SalesOrderAgentProcessingTemplateV12"; Version = "1.0.4.0" }
)

$ReferenceManifest = @(
    [pscustomobject]@{ Name = "aipod_markitdownconverter";                                                             Requirement = "Required";    Purpose = "MarkItDown document conversion" }
    [pscustomobject]@{ Name = "aipod_sharedcommondataserviceforapps_02e02";                                            Requirement = "Required";    Purpose = "Dataverse, used by most flows" }
    [pscustomobject]@{ Name = "aipod_sharedcommondataserviceforapps_294c8";                                            Requirement = "Required";    Purpose = "Dataverse, status change flow" }
    [pscustomobject]@{ Name = "aipod_salesOrderAgent.shared_commondataserviceforapps.shared-commondataser-c3a42af9-e21c-4ea4-b861-36dc7547bebe"; Requirement = "Required"; Purpose = "Dataverse, staging document processor" }
    [pscustomobject]@{ Name = "crde4_aipod.cr.shared_commondataserviceforapps.c3a42af9-e21c-4ea4-b861-36dc7547bebe";    Requirement = "Required";    Purpose = "Dataverse, status change flow" }
    [pscustomobject]@{ Name = "new_sharedagentnode_1b241228";                                                          Requirement = "Required";    Purpose = "Agent invocation from flows" }
    [pscustomobject]@{ Name = "new_sharedoffice365_deb36";                                                             Requirement = "Required";    Purpose = "Outlook intake and notifications" }
    [pscustomobject]@{ Name = "aipod_salesorderagentv1.2_byW5hK.cr.shared_dynamicsax.937fc884-b424-427b-bf76-e803310108c5"; Requirement = "Required"; Purpose = "Finance and Operations ERP tool used by the agent" }
    [pscustomobject]@{ Name = "aipod_salesorderagentv1.2_byW5hK.cr.shared_commondataser.c3a42af9-e21c-4ea4-b861-36dc7547bebe"; Requirement = "Required"; Purpose = "Dataverse tool used by the agent" }
    [pscustomobject]@{ Name = "cr875_sharedmicrosoftcopilotstudio_db931";                                              Requirement = "SharedMailbox"; Purpose = "Copilot Studio, shared-mailbox intake flow only" }
)

$EnvironmentVariableManifest = @(
    [pscustomobject]@{ Name = "aipod_CompanyCode";                 Requirement = "Required";      Purpose = "Finance and Operations legal entity" }
    [pscustomobject]@{ Name = "aipod_MailboxToMonitor";            Requirement = "Intake";        Purpose = "Mailbox for the personal-mailbox intake flow" }
    [pscustomobject]@{ Name = "aipod_MailboxFolderToMonitor";      Requirement = "Intake";        Purpose = "Folder within that mailbox" }
    [pscustomobject]@{ Name = "aipod_SharedMailboxToMonitor";      Requirement = "SharedMailbox"; Purpose = "Mailbox for the shared-mailbox intake flow" }
    [pscustomobject]@{ Name = "aipod_SharedMailboxFolderToMonitor"; Requirement = "SharedMailbox"; Purpose = "Folder within the shared mailbox" }
    [pscustomobject]@{ Name = "aipod_ProcessImagesAttachments";    Requirement = "Required";      Purpose = "Whether image attachments are processed" }
    [pscustomobject]@{ Name = "aipod_ReviewerEmailAddress";        Requirement = "Conditional";   Purpose = "Recipient of parsing-failure notifications" }
)

# The email intake flows. These must stay stopped until acceptance passes.
$AutomaticFlowNames = @(
    "When sales order email with attachment arrives"
    "When a new email with attachment arrives in a shared mailbox (V2)"
)

# Flows the pipeline cannot run without. A managed import can leave these off.
# "Process Ready Staging Documen" is the flow that picks up a document once its
# status becomes Ready, so it is required even for a manual acceptance test.
# "WhenStatusChanges" drives the agent from record status changes.
$RequiredFlowNames = @(
    "WhenStatusChanges"
    "LoadSalesOrderData"
    "Sales Order Document Parsing - Process Ready Staging Documen"
    "get_staging_document_file_content"
    "get_staging_document_file_content_native"
    "Update Processing Status to Valid"
)

# Useful but not needed to process a document.
$OptionalFlowNames = @(
    "Reprocess the not processed order lines"
    "SOA V3 - Notify"
    "SOA - Parsing Notify"
)

# ---------------------------------------------------------------------------
# Result collection
# ---------------------------------------------------------------------------

$script:Results = New-Object System.Collections.Generic.List[object]

function Add-Result {
    param(
        [Parameter(Mandatory = $true)][string] $Area,
        [Parameter(Mandatory = $true)][string] $Check,
        [Parameter(Mandatory = $true)][ValidateSet("PASS", "FAIL", "WARN", "UNKNOWN", "SKIPPED")][string] $Status,
        [Parameter()][string] $Detail = "",
        [Parameter()][string] $Fix = ""
    )
    $script:Results.Add([pscustomobject]@{
        Area   = $Area
        Check  = $Check
        Status = $Status
        Detail = $Detail
        Fix    = $Fix
    })

    $colour = switch ($Status) {
        "PASS"    { "Green" }
        "FAIL"    { "Red" }
        "WARN"    { "Yellow" }
        "UNKNOWN" { "Magenta" }
        default   { "DarkGray" }
    }
    $line = "{0,-8} {1,-22} {2}" -f $Status, $Area, $Check
    Write-Host $line -ForegroundColor $colour
    if ($Detail) { Write-Host "         $Detail" -ForegroundColor DarkGray }
}

function Write-Section {
    param([string] $Title)
    Write-Host ""
    Write-Host "== $Title" -ForegroundColor Cyan
}

# ---------------------------------------------------------------------------
# Dataverse access
# ---------------------------------------------------------------------------

$envUrl = $PowerPlatformEnvironmentUrl.TrimEnd('/')

function Get-DataverseToken {
    param([string] $Resource)
    $raw = & az account get-access-token --resource $Resource --query accessToken -o tsv 2>&1
    if ($LASTEXITCODE -ne 0) { return $null }
    # The Azure CLI can emit warnings on stdout; the token is the last non-empty line.
    $token = ($raw | Where-Object { $_ -and ($_ -notmatch '^\s*(WARNING|UserWarning|/|D:\\)') } | Select-Object -Last 1)
    if (-not $token) { return $null }
    return $token.ToString().Trim()
}

function Invoke-Dataverse {
    param([string] $Path)
    $uri = "$envUrl/api/data/v9.2/$Path"
    return Invoke-RestMethod -Uri $uri -Headers $script:DataverseHeaders -Method GET
}

Write-Host ""
Write-Host "Sales Order Document Parsing - readiness check" -ForegroundColor Cyan
Write-Host "Environment: $envUrl"

Write-Section "Access"

$token = Get-DataverseToken -Resource $envUrl
if (-not $token) {
    Add-Result -Area "Access" -Check "Dataverse sign-in" -Status "FAIL" `
        -Detail "Could not acquire a token for $envUrl." `
        -Fix "Run: az login --allow-no-subscriptions, then rerun this script."
    Write-Host ""
    Write-Host "Cannot continue without Dataverse access." -ForegroundColor Red
    exit 1
}
$script:DataverseHeaders = @{
    Authorization    = "Bearer $token"
    Accept           = "application/json"
    "OData-Version"  = "4.0"
}

try {
    $who = Invoke-Dataverse "WhoAmI"
    Add-Result -Area "Access" -Check "Dataverse sign-in" -Status "PASS" -Detail "User $($who.UserId)"
}
catch {
    Add-Result -Area "Access" -Check "Dataverse sign-in" -Status "FAIL" `
        -Detail $_.Exception.Message `
        -Fix "Confirm the environment URL and that your account has access to it."
    exit 1
}

# ---------------------------------------------------------------------------
# Solutions
# ---------------------------------------------------------------------------

Write-Section "Solutions"

$installedSolutions = @{}
try {
    $sols = Invoke-Dataverse "solutions?`$select=solutionid,uniquename,version,ismanaged,installedon"
    foreach ($s in $sols.value) { $installedSolutions[$s.uniquename] = $s }
}
catch {
    Add-Result -Area "Solutions" -Check "Read installed solutions" -Status "UNKNOWN" -Detail $_.Exception.Message
}

foreach ($expected in $ExpectedSolutions) {
    $found = $installedSolutions[$expected.UniqueName]
    if (-not $found) {
        Add-Result -Area "Solutions" -Check $expected.UniqueName -Status "FAIL" `
            -Detail "Not installed." `
            -Fix "Import it. The connector solution must be imported before the main solution."
        continue
    }
    if (-not $found.ismanaged) {
        Add-Result -Area "Solutions" -Check $expected.UniqueName -Status "WARN" `
            -Detail "Installed as unmanaged (version $($found.version))." `
            -Fix "Supported installs are managed. An unmanaged import cannot be cleanly removed."
        continue
    }
    if ($found.version -ne $expected.Version) {
        Add-Result -Area "Solutions" -Check $expected.UniqueName -Status "WARN" `
            -Detail "Version $($found.version), expected $($expected.Version)." `
            -Fix "This script was written for $($expected.Version). Results may not apply."
        continue
    }
    Add-Result -Area "Solutions" -Check $expected.UniqueName -Status "PASS" -Detail "Managed, version $($found.version)."
}

# ---------------------------------------------------------------------------
# Connector definition
# ---------------------------------------------------------------------------

Write-Section "Connector"

$connector = $null
try {
    $connectors = Invoke-Dataverse "connectors?`$select=name,connectorinternalid,statuscode,openapidefinition,connectionparameters&`$filter=contains(connectorinternalid,'markitdown')"
    if ($connectors.value.Count -eq 0) {
        Add-Result -Area "Connector" -Check "MarkItDown connector installed" -Status "FAIL" `
            -Detail "No connector found." `
            -Fix "Import SalesOrderMarkItDownConnector_1.0.1.0_managed.zip."
    }
    elseif ($connectors.value.Count -gt 1) {
        $connector = $connectors.value[0]
        Add-Result -Area "Connector" -Check "MarkItDown connector installed" -Status "WARN" `
            -Detail "$($connectors.value.Count) MarkItDown connectors exist: $(($connectors.value.connectorinternalid) -join ', ')" `
            -Fix "Duplicates make connection binding ambiguous. Keep only the one from the shipped solution."
    }
    else {
        $connector = $connectors.value[0]
        Add-Result -Area "Connector" -Check "MarkItDown connector installed" -Status "PASS" `
            -Detail "$($connector.connectorinternalid)"
    }
}
catch {
    Add-Result -Area "Connector" -Check "MarkItDown connector installed" -Status "UNKNOWN" -Detail $_.Exception.Message
}

if ($connector) {
    try {
        $def = $connector.openapidefinition | ConvertFrom-Json
        $paths = @($def.paths.PSObject.Properties.Name)
        $okBase = ($def.basePath -eq "/api")
        $okPath = ($paths -contains "/convert")
        $okKey  = $null -ne $def.securityDefinitions.api_key
        if ($okBase -and $okPath -and $okKey) {
            Add-Result -Area "Connector" -Check "Connector definition" -Status "PASS" `
                -Detail "basePath /api, path /convert, x-functions-key header."
        }
        else {
            Add-Result -Area "Connector" -Check "Connector definition" -Status "FAIL" `
                -Detail "basePath='$($def.basePath)' paths='$($paths -join ',')' apiKey=$okKey" `
                -Fix "The installed connector does not match the shipped definition. Reimport the connector solution."
        }

        $hostParam = $connector.connectionparameters | ConvertFrom-Json
        if ($hostParam.PSObject.Properties['functionHost'] -and $hostParam.PSObject.Properties['api_key']) {
            Add-Result -Area "Connector" -Check "Connection parameters" -Status "PASS" `
                -Detail "Asks for 'Function host' and 'Function key'."
        }
        else {
            Add-Result -Area "Connector" -Check "Connection parameters" -Status "FAIL" `
                -Detail "Expected functionHost and api_key." `
                -Fix "Reimport the connector solution."
        }
    }
    catch {
        Add-Result -Area "Connector" -Check "Connector definition" -Status "UNKNOWN" -Detail $_.Exception.Message
    }
}

# ---------------------------------------------------------------------------
# Connection references
# ---------------------------------------------------------------------------

Write-Section "Connection references"

$installedRefs = @{}
try {
    $refs = Invoke-Dataverse "connectionreferences?`$select=connectionreferencelogicalname,connectionreferencedisplayname,connectionid,connectorid"
    foreach ($r in $refs.value) { $installedRefs[$r.connectionreferencelogicalname] = $r }
}
catch {
    Add-Result -Area "Connection refs" -Check "Read connection references" -Status "UNKNOWN" -Detail $_.Exception.Message
}

# The MarkItDown connection stores the Function hostname it will call. A
# connection can be Connected while pointing at a decommissioned or wrong
# Function app, which surfaces later as ConversionToolUnavailable. Compare what
# the connection actually stores against the host being checked.
if ($FunctionHost) {
    $mkRef = $installedRefs["aipod_markitdownconverter"]
    if ($mkRef -and -not [string]::IsNullOrWhiteSpace($mkRef.connectionid)) {
        $storedHost = $null
        try {
            $paToken = Get-DataverseToken -Resource "https://service.powerapps.com/"
            if ($paToken) {
                $paHeaders = @{ Authorization = "Bearer $paToken"; Accept = "application/json" }
                # The connections API is environment-scoped, so resolve the
                # environment id from the Dataverse URL first.
                $envList = Invoke-RestMethod -Uri "https://api.powerapps.com/providers/Microsoft.PowerApps/environments?api-version=2016-11-01" -Headers $paHeaders
                $match = $envList.value | Where-Object {
                    $u = $_.properties.linkedEnvironmentMetadata.instanceUrl
                    $u -and ($u.TrimEnd('/') -ieq $envUrl.TrimEnd('/'))
                } | Select-Object -First 1
                if ($match) {
                    $apiName = ($mkRef.connectorid -replace '.*/apis/', '')
                    $connUri = "https://api.powerapps.com/providers/Microsoft.PowerApps/apis/$apiName/connections/$($mkRef.connectionid)?api-version=2016-11-01&`$filter=environment eq '$($match.name)'"
                    $conn = Invoke-RestMethod -Uri $connUri -Headers $paHeaders
                    $storedHost = $conn.properties.connectionParameters.functionHost
                }
            }
        }
        catch { }

        if (-not $storedHost) {
            Add-Result -Area "Connection refs" -Check "MarkItDown connection target" -Status "UNKNOWN" `
                -Detail "Could not read the connection's stored Function host." `
                -Fix "Open the connection and confirm its Function host matches your deployed Function app."
        }
        elseif ($storedHost.Trim() -ieq $FunctionHost.Trim()) {
            Add-Result -Area "Connection refs" -Check "MarkItDown connection target" -Status "PASS" `
                -Detail "Points at $storedHost."
        }
        else {
            Add-Result -Area "Connection refs" -Check "MarkItDown connection target" -Status "FAIL" `
                -Detail "Connection points at '$storedHost' but the Function app is '$FunctionHost'." `
                -Fix "Edit the MarkItDown connection and set Function host to '$FunctionHost'. A wrong host still shows Connected and fails later with ConversionToolUnavailable."
        }
    }
}

foreach ($m in $ReferenceManifest) {
    $r = $installedRefs[$m.Name]
    $shortName = if ($m.Name.Length -gt 46) { $m.Name.Substring(0, 43) + "..." } else { $m.Name }

    if (-not $r) {
        Add-Result -Area "Connection refs" -Check $shortName -Status "UNKNOWN" `
            -Detail "Not visible. $($m.Purpose)" `
            -Fix "Either the main solution is not imported, or you cannot see this record."
        continue
    }

    $bound = -not [string]::IsNullOrWhiteSpace($r.connectionid)
    $connectorResolved = -not [string]::IsNullOrWhiteSpace($r.connectorid)

    if (-not $connectorResolved) {
        Add-Result -Area "Connection refs" -Check $shortName -Status "FAIL" `
            -Detail "Connector not resolved. $($m.Purpose)" `
            -Fix "Import the connector solution first, then reimport the main solution."
        continue
    }

    switch ($m.Requirement) {
        "Unused" {
            if ($bound) {
                Add-Result -Area "Connection refs" -Check $shortName -Status "WARN" `
                    -Detail "Bound, but not used by this release." `
                    -Fix "Harmless. It can be left as it is."
            }
            else {
                Add-Result -Area "Connection refs" -Check $shortName -Status "SKIPPED" `
                    -Detail "Not used by this release. Leave unbound."
            }
        }
        "SharedMailbox" {
            if ($bound) {
                Add-Result -Area "Connection refs" -Check $shortName -Status "PASS" -Detail $m.Purpose
            }
            elseif ($SharedMailboxIntake) {
                Add-Result -Area "Connection refs" -Check $shortName -Status "FAIL" `
                    -Detail "Not bound, and shared-mailbox intake was selected. $($m.Purpose)" `
                    -Fix "Create the connection and bind this reference."
            }
            else {
                Add-Result -Area "Connection refs" -Check $shortName -Status "SKIPPED" `
                    -Detail "Only needed for shared-mailbox intake."
            }
        }
        default {
            if ($bound) {
                Add-Result -Area "Connection refs" -Check $shortName -Status "PASS" -Detail $m.Purpose
            }
            else {
                Add-Result -Area "Connection refs" -Check $shortName -Status "FAIL" `
                    -Detail "Not bound. $($m.Purpose)" `
                    -Fix "Open the connection reference and select a connection."
            }
        }
    }
}

$unexpected = $installedRefs.Keys | Where-Object { $ReferenceManifest.Name -notcontains $_ }
$ourRefs = $installedRefs.Keys | Where-Object { $ReferenceManifest.Name -contains $_ }
if ($ourRefs.Count -gt 0 -and $unexpected.Count -gt 0) {
    Add-Result -Area "Connection refs" -Check "Other references in environment" -Status "SKIPPED" `
        -Detail "$($unexpected.Count) connection references belong to other solutions and were not checked."
}

# ---------------------------------------------------------------------------
# Environment variables
# ---------------------------------------------------------------------------

Write-Section "Environment variables"

$definitions = @{}
$values = @{}
try {
    $defs = Invoke-Dataverse "environmentvariabledefinitions?`$select=schemaname,defaultvalue,type,environmentvariabledefinitionid"
    foreach ($d in $defs.value) { $definitions[$d.schemaname] = $d }
    $vals = Invoke-Dataverse "environmentvariablevalues?`$select=value,_environmentvariabledefinitionid_value"
    foreach ($v in $vals.value) { $values[$v._environmentvariabledefinitionid_value] = $v.value }
}
catch {
    Add-Result -Area "Environment vars" -Check "Read environment variables" -Status "UNKNOWN" -Detail $_.Exception.Message
}

foreach ($m in $EnvironmentVariableManifest) {
    $d = $definitions[$m.Name]
    if (-not $d) {
        Add-Result -Area "Environment vars" -Check $m.Name -Status "UNKNOWN" `
            -Detail "Definition not visible. $($m.Purpose)" `
            -Fix "Confirm the main solution imported."
        continue
    }

    $current = $null
    if ($values.ContainsKey($d.environmentvariabledefinitionid)) { $current = $values[$d.environmentvariabledefinitionid] }
    $effective = if (-not [string]::IsNullOrWhiteSpace($current)) { $current } else { $d.defaultvalue }
    $source    = if (-not [string]::IsNullOrWhiteSpace($current)) { "current value" } else { "default" }
    $hasValue  = -not [string]::IsNullOrWhiteSpace($effective)

    $required = switch ($m.Requirement) {
        "Required"      { $true }
        "Intake"        { -not $SharedMailboxIntake }
        "SharedMailbox" { [bool] $SharedMailboxIntake }
        default         { $false }
    }

    if ($hasValue) {
        Add-Result -Area "Environment vars" -Check $m.Name -Status "PASS" -Detail "'$effective' (from $source)"
    }
    elseif ($required) {
        Add-Result -Area "Environment vars" -Check $m.Name -Status "FAIL" `
            -Detail "No value. $($m.Purpose)" `
            -Fix "Set it in the maker portal under the solution's environment variables."
    }
    else {
        Add-Result -Area "Environment vars" -Check $m.Name -Status "WARN" `
            -Detail "No value. $($m.Purpose)" `
            -Fix "Set it if you use the feature that reads it."
    }
}

# ---------------------------------------------------------------------------
# Application user for the Function's managed identity
# ---------------------------------------------------------------------------

Write-Section "Application user"

if (-not $IdentityClientId) {
    Add-Result -Area "Application user" -Check "Managed identity application user" -Status "SKIPPED" `
        -Detail "No -IdentityClientId supplied." `
        -Fix "Pass the Managed identity client ID from YOUR-VALUES.md to check this."
}
else {
    try {
        $appUsers = Invoke-Dataverse ("systemusers?`$select=fullname,applicationid,isdisabled,azureactivedirectoryobjectid&`$filter=applicationid eq {0}" -f $IdentityClientId)
        if ($appUsers.value.Count -eq 0) {
            Add-Result -Area "Application user" -Check "Managed identity application user" -Status "FAIL" `
                -Detail "No application user has application ID $IdentityClientId." `
                -Fix "Create it in the admin centre: Settings -> Users + permissions -> Application users -> New app user."
        }
        elseif ($appUsers.value.Count -gt 1) {
            Add-Result -Area "Application user" -Check "Managed identity application user" -Status "WARN" `
                -Detail "$($appUsers.value.Count) application users share that application ID." `
                -Fix "Duplicates cause confusing permission behaviour. Keep one."
        }
        else {
            $au = $appUsers.value[0]
            if ($au.isdisabled) {
                Add-Result -Area "Application user" -Check "Managed identity application user" -Status "FAIL" `
                    -Detail "The application user exists but is disabled." `
                    -Fix "Enable it."
            }
            else {
                Add-Result -Area "Application user" -Check "Managed identity application user" -Status "PASS" `
                    -Detail "$($au.fullname)"
            }

            try {
                $roles = Invoke-Dataverse ("systemusers({0})/systemuserroles_association?`$select=name" -f $au.systemuserid)
                $roleNames = @($roles.value.name)
                if ($roleNames -contains "Sales Order MarkItDown Converter") {
                    $extra = $roleNames | Where-Object { $_ -ne "Sales Order MarkItDown Converter" }
                    if ($extra.Count -gt 0) {
                        Add-Result -Area "Application user" -Check "Security role" -Status "WARN" `
                            -Detail "Has the converter role plus: $($extra -join ', ')" `
                            -Fix "The documented configuration is least privilege - only the converter role is needed."
                    }
                    else {
                        Add-Result -Area "Application user" -Check "Security role" -Status "PASS" `
                            -Detail "Sales Order MarkItDown Converter only."
                    }
                }
                else {
                    Add-Result -Area "Application user" -Check "Security role" -Status "FAIL" `
                        -Detail "Roles: $(if ($roleNames.Count) { $roleNames -join ', ' } else { 'none' })" `
                        -Fix "Assign the 'Sales Order MarkItDown Converter' role."
                }
            }
            catch {
                Add-Result -Area "Application user" -Check "Security role" -Status "UNKNOWN" -Detail $_.Exception.Message
            }
        }
    }
    catch {
        Add-Result -Area "Application user" -Check "Managed identity application user" -Status "UNKNOWN" -Detail $_.Exception.Message
    }
}

# ---------------------------------------------------------------------------
# Flow state
# ---------------------------------------------------------------------------

Write-Section "Flows"

try {
    # Scope strictly to this solution's flows. Querying every flow in the
    # environment reports hundreds of unrelated ones as failures.
    $mainSolution = $installedSolutions["SalesOrderAgentProcessingTemplateV12"]
    if (-not $mainSolution) {
        Add-Result -Area "Flows" -Check "Read flows" -Status "UNKNOWN" -Detail "Main solution not installed."
    }
    else {
        $flowComponents = Invoke-Dataverse ("solutioncomponents?`$select=objectid&`$filter=_solutionid_value eq {0} and componenttype eq 29" -f $mainSolution.solutionid)
        $byName = @{}
        foreach ($comp in $flowComponents.value) {
            try {
                $w = Invoke-Dataverse ("workflows({0})?`$select=name,statecode" -f $comp.objectid)
                $byName[$w.name] = $w
            }
            catch { }
        }

        if ($byName.Count -eq 0) {
            Add-Result -Area "Flows" -Check "Read flows" -Status "UNKNOWN" -Detail "No flows from this solution were visible."
        }

        foreach ($name in $AutomaticFlowNames) {
            $f = $byName[$name]
            if (-not $f) {
                Add-Result -Area "Flows" -Check $name -Status "UNKNOWN" -Detail "Flow not visible."
            }
            elseif ($f.statecode -eq 1) {
                Add-Result -Area "Flows" -Check $name -Status "WARN" `
                    -Detail "Turned on." `
                    -Fix "Automatic flows should stay off until one document has been verified."
            }
            else {
                Add-Result -Area "Flows" -Check $name -Status "PASS" -Detail "Stopped, as expected before acceptance."
            }
        }

        foreach ($name in $RequiredFlowNames) {
            $f = $byName[$name]
            if (-not $f) {
                Add-Result -Area "Flows" -Check $name -Status "UNKNOWN" -Detail "Flow not visible."
            }
            elseif ($f.statecode -eq 1) {
                Add-Result -Area "Flows" -Check $name -Status "PASS" -Detail "On."
            }
            else {
                Add-Result -Area "Flows" -Check $name -Status "FAIL" `
                    -Detail "Off. The pipeline cannot run without it." `
                    -Fix "Solutions -> the solution -> Cloud flows -> select it -> Turn on."
            }
        }

        foreach ($name in $OptionalFlowNames) {
            $f = $byName[$name]
            if (-not $f) {
                Add-Result -Area "Flows" -Check $name -Status "UNKNOWN" -Detail "Flow not visible."
            }
            elseif ($f.statecode -eq 1) {
                Add-Result -Area "Flows" -Check $name -Status "PASS" -Detail "On."
            }
            else {
                Add-Result -Area "Flows" -Check $name -Status "SKIPPED" -Detail "Off. Optional."
            }
        }
    }
}
catch {
    Add-Result -Area "Flows" -Check "Read flows" -Status "UNKNOWN" -Detail $_.Exception.Message
}

# ---------------------------------------------------------------------------
# Function
# ---------------------------------------------------------------------------

Write-Section "Azure Function"

if (-not $FunctionHost) {
    Add-Result -Area "Function" -Check "Function checks" -Status "SKIPPED" `
        -Detail "No -FunctionHost supplied." `
        -Fix "Rerun with -FunctionHost to check the Function."
}
else {
    $cleanHost = $FunctionHost.Trim()
    $looksWrong = $cleanHost -match '^(https?://)|[/:?#]|\s'
    if ($looksWrong) {
        Add-Result -Area "Function" -Check "Function host format" -Status "FAIL" `
            -Detail "'$cleanHost' contains a scheme, port, path or space." `
            -Fix "Use only the hostname, for example azfn1234.azurewebsites.net. The connector rejects anything else."
    }
    else {
        Add-Result -Area "Function" -Check "Function host format" -Status "PASS" -Detail $cleanHost
    }

    $convertUri = "https://$cleanHost/api/convert"

    try {
        $resp = Invoke-WebRequest -Uri $convertUri -Method POST -Body '{}' -ContentType 'application/json' `
                                  -SkipHttpErrorCheck -TimeoutSec 60
        if ($resp.StatusCode -eq 401) {
            Add-Result -Area "Function" -Check "Unauthenticated call rejected" -Status "PASS" -Detail "HTTP 401."
        }
        elseif ($resp.StatusCode -eq 404) {
            Add-Result -Area "Function" -Check "Unauthenticated call rejected" -Status "FAIL" `
                -Detail "HTTP 404 - the /api/convert route is not registered." `
                -Fix "The Python application did not start. Redeploy with a remote build."
        }
        elseif ($resp.StatusCode -eq 200) {
            Add-Result -Area "Function" -Check "Unauthenticated call rejected" -Status "FAIL" `
                -Detail "HTTP 200 - the Function is not protected." `
                -Fix "Stop and investigate. Anonymous callers can reach the converter."
        }
        else {
            Add-Result -Area "Function" -Check "Unauthenticated call rejected" -Status "WARN" `
                -Detail "HTTP $($resp.StatusCode), expected 401."
        }
    }
    catch {
        Add-Result -Area "Function" -Check "Unauthenticated call rejected" -Status "UNKNOWN" `
            -Detail $_.Exception.Message `
            -Fix "Check the hostname and that the Function app is running."
    }

    if (-not $FunctionKey) {
        Add-Result -Area "Function" -Check "Keyed call accepted" -Status "SKIPPED" `
            -Detail "No -FunctionKey supplied." `
            -Fix "This is the check that proves the key works. Rerun with -FunctionKey."
    }
    else {
        $plain = [System.Net.NetworkCredential]::new("", $FunctionKey).Password
        $keyedResponse = $null
        $keyedError = $null
        # A cold Function app can drop the first connection. Retry transport
        # failures only; an HTTP response of any status is authoritative.
        for ($attempt = 1; $attempt -le 3; $attempt++) {
            try {
                $keyedResponse = Invoke-WebRequest -Uri $convertUri -Method POST -Body '{}' `
                            -ContentType 'application/json' `
                            -Headers @{ 'x-functions-key' = $plain } `
                            -SkipHttpErrorCheck -TimeoutSec 120
                $keyedError = $null
                break
            }
            catch {
                $keyedError = $_.Exception.Message
                if ($attempt -lt 3) { Start-Sleep -Seconds 10 }
            }
        }

        if (-not $keyedResponse) {
            Add-Result -Area "Function" -Check "Keyed call accepted" -Status "UNKNOWN" `
                -Detail "No response after 3 attempts. $keyedError" `
                -Fix "Check network access to the Function host, then run this again."
        }
        else {
            $body = ""
            try { $body = $keyedResponse.Content } catch { }

            if ($keyedResponse.StatusCode -eq 400 -and $body -match 'MissingStagingDocumentId') {
                Add-Result -Area "Function" -Check "Keyed call accepted" -Status "PASS" `
                    -Detail "HTTP 400 MissingStagingDocumentId - the key works and the deployed code answered."
            }
            elseif ($keyedResponse.StatusCode -eq 401) {
                Add-Result -Area "Function" -Check "Keyed call accepted" -Status "FAIL" `
                    -Detail "HTTP 401 - the key was rejected." `
                    -Fix "Copy the default host key again from the Function app's App keys blade."
            }
            elseif ($keyedResponse.StatusCode -eq 404) {
                Add-Result -Area "Function" -Check "Keyed call accepted" -Status "FAIL" `
                    -Detail "HTTP 404 - the route is missing." `
                    -Fix "Redeploy the Function with a remote build."
            }
            else {
                Add-Result -Area "Function" -Check "Keyed call accepted" -Status "WARN" `
                    -Detail "HTTP $($keyedResponse.StatusCode). Body: $($body.Substring(0, [Math]::Min(200, $body.Length)))"
            }
        }
        $plain = $null
    }
}

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------

Write-Host ""
Write-Host "================ SUMMARY ================" -ForegroundColor Cyan

$counts = $script:Results | Group-Object Status | ForEach-Object { "$($_.Name)=$($_.Count)" }
Write-Host ($counts -join "  ")

$failures = @($script:Results | Where-Object { $_.Status -eq "FAIL" })
$unknowns = @($script:Results | Where-Object { $_.Status -eq "UNKNOWN" })

if ($failures.Count -gt 0) {
    Write-Host ""
    Write-Host "Must be fixed:" -ForegroundColor Red
    foreach ($f in $failures) {
        Write-Host "  - [$($f.Area)] $($f.Check): $($f.Detail)"
        if ($f.Fix) { Write-Host "      Fix: $($f.Fix)" -ForegroundColor Yellow }
    }
}

if ($unknowns.Count -gt 0) {
    Write-Host ""
    Write-Host "Could not be determined - treat as not yet proven:" -ForegroundColor Magenta
    foreach ($u in $unknowns) { Write-Host "  - [$($u.Area)] $($u.Check): $($u.Detail)" }
}

Write-Host ""
if ($failures.Count -eq 0 -and $unknowns.Count -eq 0) {
    Write-Host "Configuration checks passed." -ForegroundColor Green
    Write-Host "This does not mean the system works. Process one real document and" -ForegroundColor Yellow
    Write-Host "confirm the result in Dataverse and in Finance and Operations before" -ForegroundColor Yellow
    Write-Host "turning on the automatic flows." -ForegroundColor Yellow
    exit 0
}

if ($failures.Count -eq 0) {
    Write-Host "No failures, but some checks could not be completed." -ForegroundColor Yellow
    exit 0
}

Write-Host "Not ready. Fix the items above and run this again." -ForegroundColor Red
exit 1


