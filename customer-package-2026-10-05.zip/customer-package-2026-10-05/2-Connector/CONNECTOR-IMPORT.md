# Unit 2 — Import the Connector and Create the Connection

Do this **after** Unit 1 (Azure) and **before** Unit 3 (main solution).

The custom connector is what lets Power Platform call the Azure Function that
converts documents. It must exist in the environment *before* the main solution
is imported, because the main solution contains connection references that
point at it.

> **Import order matters.** If the main solution is imported first, there is no
> connector for its references to resolve against and the Connector field is
> left blank and disabled. Fixing that means removing the main solution and
> starting this unit again.

---

## What you need before you start

Open `YOUR-VALUES.md` in the package root. The Azure installer wrote it, and it
contains the exact hostname to paste.

| Value | Where it comes from |
|---|---|
| **Function host** | `YOUR-VALUES.md`, or `1-Azure\files\Azure-Deployment-Result.txt` |
| **Function key** | Azure portal — you copy this yourself, see Step 2 |

The installer never writes the Function key to disk, so you must copy it from
the portal. Do not paste it into email, tickets, chat, or documentation.

---

## Step 1 — Import the connector solution

1. Go to `https://make.powerapps.com`
2. Top right, confirm the **environment picker** shows the environment you are
   installing into. This is the most common place to go wrong.
3. In the left navigation choose **Solutions**
4. On the command bar choose **Import solution**
5. Choose **Browse**, select
   `2-Connector\SalesOrderMarkItDownConnector_1.0.1.1_managed.zip`
6. Choose **Next**
7. Confirm the panel shows **Sales Order MarkItDown Connector**, version **1.0.1.1**, and that it will be imported as **managed**
8. Choose **Import**
9. Wait until the notification says the import succeeded

This solution contains only the connector. It creates no flows, tables, agents,
or connections.

**If the import fails**, read the error. A missing-dependency error here almost
always means the wrong environment was selected in step 2.

---

## Step 2 — Copy the Function key from Azure

1. Go to `https://portal.azure.com`
2. Search for the Function app name shown in `YOUR-VALUES.md`, for example
   `azfn1234`
3. Open it
4. In the left navigation, under **Functions**, choose **App keys**
5. In the **Host keys** section, find the key named **default**
6. Choose the eye icon to reveal it, then the copy icon

Keep it on the clipboard for the next step. If you lose it, come back here — the
key can be copied again at any time.

---

## Step 3 — Create the connection

1. In `https://make.powerapps.com`, confirm the environment picker again
2. Left navigation → **Connections**  (if you do not see it, choose **… More**)
3. Command bar → **+ New connection**
4. In the search box type `MarkItDown`
5. Select **Sales Order MarkItDown Converter** from the results
6. A dialog appears asking for two values:

| Dialog label | What to enter |
|---|---|
| **Function host** | The hostname only, for example `azfn1234.azurewebsites.net` |
| **Function key** | The `default` host key copied in Step 2 |

7. Choose **Create**
8. Wait for the connection to appear in the list with status **Connected**

### Getting the Function host exactly right

The connector validates this field against a strict pattern. These are all
**rejected**:

| Wrong | Why |
|---|---|
| `https://azfn1234.azurewebsites.net` | Remove `https://` |
| `azfn1234.azurewebsites.net/` | Remove the trailing slash |
| `azfn1234.azurewebsites.net/api` | No path — the connector adds it |
| `azfn1234.azurewebsites.net:443` | No port |
| ` azfn1234.azurewebsites.net ` | Leading or trailing space |
| `azfn1234` | Must be the full DNS name |

The only correct form is the bare hostname:

```
azfn1234.azurewebsites.net
```

Copy it from `YOUR-VALUES.md` rather than typing it.

### Create exactly one connection

If something fails later, do not create a second connection to work around it.
Duplicates make the binding in Unit 3 ambiguous and cause confusing behaviour
after upgrades. Fix or delete the first one instead.

---

## Step 4 — Check before moving on

| Check | Expected |
|---|---|
| Connector solution appears under **Solutions** | Sales Order MarkItDown Connector 1.0.1.1, managed |
| Connection appears under **Connections** | Status **Connected** |
| Unauthenticated call to the Function | **401** (Unit 1 verification) |

> **What "Connected" does and does not mean.** It means a connection record was
> created and the values were stored. It does **not** mean the hostname is
> reachable, the key is valid, or the Function is running. Power Platform does
> not call the backend when a connection is created, so a wrong key still looks
> Connected and only fails when a flow runs.

To actually prove the host and key work, run the readiness check from the
package root once Unit 3 is complete:

```powershell
.\Test-Readiness.ps1 `
    -PowerPlatformEnvironmentUrl "https://<your-env>.crm.dynamics.com" `
    -FunctionHost "azfn1234.azurewebsites.net" `
    -FunctionKey (Read-Host "Function key" -AsSecureString)
```

A working key returns **HTTP 400 `MissingStagingDocumentId`**. That is a
success: it proves the key was accepted and the deployed code answered, without
processing or changing any data.

Continue to Unit 3.
