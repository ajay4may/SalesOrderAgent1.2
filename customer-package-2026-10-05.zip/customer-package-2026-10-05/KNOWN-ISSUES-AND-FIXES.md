# Known Issues and How This Package Handles Them

The items below are the conditions most likely to affect an installation, with
the symptom, the cause, and the fix. They are recorded so you can recognise
them quickly rather than diagnose them from scratch.

---

## 1. Blank Connector field after importing the main solution

**Symptom.** Import succeeds. A connection reference shows an empty, disabled
Connector field. Flows fail with `ConnectionAuthorizationFailed`, or the import
reports *"The connections could not be loaded."*

**Cause.** The main solution references the custom connector by an internal API
name. Your environment assigns the connector a **different** API name from the
one recorded in the source environment.

**This is expected and is handled, provided you import in the documented
order.** Importing the connector solution first lets Power Platform resolve the
main solution's connection references to your own copy of the connector.

**How this package handles it.** The connector ships as its own solution and is
imported **first**, so it exists before any connection reference is created and
Power Platform can rewrite the reference to the local connector.

**How to confirm.** After importing the main solution, open each connection
reference that uses the connector and confirm the Connector field is populated
and editable.

**If it is blank.** The most likely cause is that the main solution was
imported before the connector, or that a different MarkItDown connector already
existed in the environment. Do not create extra connections and do not
hand-edit flows. Remove the main solution, confirm the connector solution is
installed, and import again in order.

---

## 2. Scanned PDFs and email bodies stop extracting after publishing the agent

**Symptom.** Digital PDFs still work. Scanned PDFs and plain-text email bodies
fail with `NativeExtractionUnavailable`, `NativeFileUnavailable`, or
`NativeFileContentMissing`. The flow run history shows the file retrieval
**succeeded**.

**Cause.** The agent tool flow `get_staging_document_file_content_native`
returns the document to the agent in a `filecontent` property. That property
can be dropped from the flow's response when the flow is opened in the designer
or the agent is republished. The flow still reports success and a correct byte
count, but hands the agent nothing.

**How to detect it.** Run one scanned PDF and one plain-text email body. If both
fail while a digital PDF succeeds, this is almost certainly the cause.

**How to fix it.** In the flow's success response action, the `filecontent`
property must be present and set to:

```
@outputs('Download_a_file_or_an_image')?['body']
```

Both response actions return status code 200, so they must declare an identical
schema. If you add `filecontent` to one you must add it to the other, otherwise
the save fails with `ActionSchemaInvalid`.

---

## 2a. Import stops with a red icon on a connection reference

**Symptom.** On the **Connections** page of the import wizard, one reference
shows a red icon and the **Next** button stays greyed out.

**Cause.** Every connection reference in the solution must be bound to a
connection before the import can proceed. A reference whose connector has no
connection in the environment cannot be satisfied.

**Fix.** Bind the reference showing the red icon. All ten references in this
solution are used and all ten must be bound. If a connector has no connection
yet, choose **+ New connection** from the row's **…** menu, complete the
sign-in, then return.

> Earlier builds shipped two extra connection references that nothing used,
> including one called **MarkItDown Converter (Entra ID)**. They have been
> removed. If you see either of those, you are installing an old package.

---

## 2b. Processing fails with ConversionToolUnavailable

**Symptom.** A document reaches **Processing failed** with:

```text
Error Code: ConversionToolUnavailable
Summary: Processing failed because the hosted document conversion
         capability was unavailable.
```

The MarkItDown connection shows **Connected**, and the conversion flows show
**no runs at all** for the failed document.

**Cause.** The connection is pointing at the wrong Azure Function hostname.
Power Platform does **not** call the backend when a connection is created, so
a connection holding a wrong, old or decommissioned host still shows
**Connected**. The failure only appears when a document is processed.

This is easy to hit if you have more than one Function app, or if you rebuilt
the Azure resources and reused an older connection.

**How to confirm.** Call the host stored in the connection directly:

```powershell
Invoke-WebRequest -Uri "https://<host-in-the-connection>/api/convert" `
  -Method POST -Body '{}' -ContentType 'application/json' -SkipHttpErrorCheck
```

| Response | Meaning |
|---|---|
| **401** | Correct host. The Function is deployed and protected. |
| **404** | Wrong host, or that Function app is not serving the converter. |
| Cannot resolve | The host does not exist. |

Compare it with the **Function host** in `YOUR-VALUES.md`. They must match
exactly.

**Fix.**

1. `make.powerapps.com` → **Connections**
2. Find the **Sales Order MarkItDown Converter** connection
3. Delete it, then choose **+ New connection** and create it again with:
   - **Function host** - the exact value from `YOUR-VALUES.md`, no `https://`,
     no trailing slash
   - **Function key** - the `default` host key from the Azure portal
4. Open the solution → **Connection references** →
   **MarkItDown Converter (Function Key)** and bind it to the new connection
5. Re-run `Test-Readiness.ps1`, then reprocess the document

**Prevention.** `Test-Readiness.ps1` now reads the hostname stored inside the
connection and compares it with the `-FunctionHost` you supply. A mismatch is
reported as **MarkItDown connection target - FAIL** before you process
anything.

---

## 2c. Document conversion never happens

**Symptom.** The MarkItDown connection looks fine and shows **Connected**, but
nothing is converted.

**Cause.** The **MarkItDown Converter (Function Key)** connection reference is
not bound to the connection you created in Unit 2, or is bound to a different
connection.

**Fix.** Open the solution's connection references and confirm
**MarkItDown Converter (Function Key)** points at that connection.
`Test-Readiness.ps1` reports this directly.

> Earlier builds also shipped a **MarkItDown Converter (Entra ID)** reference
> that nothing used. It has been removed. If you see it, you are installing an
> old package.

---

## 2d. Nothing processes because the supporting flows are off

**Symptom.** A document arrives, the staging row is created, and then nothing
happens. No error appears.

**Cause.** A managed import can leave flows switched off. The two email intake
flows are *meant* to be off during acceptance, but the flows that do the work
are not.

**Fix.** Turn these on:

- `Sales Order Document Parsing - Process Ready Staging Documen` — this is the
  one that picks a document up once its status becomes Ready
- `WhenStatusChanges`
- `get_staging_document_file_content`
- `get_staging_document_file_content_native`
- `LoadSalesOrderData`
- `Update Processing Status to Valid`

`Test-Readiness.ps1` lists any that are off.

---

## 2e. Documents stop processing and runs sit in "Waiting"

**Symptom.** A document is picked up but never finishes. The run history for
`Sales Order Document Parsing - Process Ready Staging Documen` shows runs with
status **Waiting** and the error `WorkflowMaximumWaitingRunCountExceeded`. The
trigger shows **Succeeded** but the run has **0 actions**, so it never started.

**How to tell it apart from a configuration problem.** Check another flow in
the solution. If other flows run normally, the environment is healthy and only
this flow's queue is stuck.

**What does not work.** Waiting runs cannot be cancelled through the API - the
cancel call returns HTTP 400. Turning the flow off and on does not clear the
queue either.

**Fix.** Open the flow in the designer, select the trigger, open **Settings**,
and turn **Concurrency Control** off or raise the degree of parallelism, then
save. Resubmit or retrigger afterwards.

> Do not try to fix this by editing the flow definition outside the designer.
> The solution contains a `concurrency` setting on a loop action as well as the
> trigger, and changing the wrong one has no effect on the queue.

**Avoiding it.** Do not retrigger a document repeatedly while a run is still
queued. Set the status to Ready once, then wait.

---

## 3. Function returns 404 instead of 401

**Symptom.** Every document fails. Calling `/api/convert` returns 404.

**Cause.** The Python application was deployed without a remote build, so
`requirements.txt` was never installed and the route never registered.

**Fix.** Redeploy with a remote build. The supplied installer already does this.
A healthy, protected Function returns **401** to an unauthenticated call.

---

## 3a. Installation stops with AADSTS50078 or "multi-factor authentication has expired"

**Symptom.** Provisioning succeeds, then deployment fails with
`invalid_grant AADSTS50078: Presented multi-factor authentication has expired`.

**Cause.** Deploying the Function package needs an **App Service** scoped
token, which Entra issues separately from the management token used for
everything earlier in the installer. Conditional access policies can leave the
management token valid while requiring a fresh sign-in for App Service, so the
failure appears in the middle of an otherwise healthy run.

**Fix.** Refresh that scope and rerun the installer:

```powershell
az login --scope "https://appservice.azure.com/.default"
```

The installer now probes this scope during sign-in validation and prompts
before provisioning, so it should normally be handled for you. If it still
appears, the command above resolves it. Sign-in failures are reported
immediately rather than retried.

---

## 4. Connector calling the wrong path

**Symptom.** Connector action fails even though the Function is healthy.

**Cause.** The connector must call `/api/convert`, not `/convert`.

**Status.** Correct in this package. The connector's base path is `/api` and its
operation path is `/convert`. If you edit the connector, keep this split.

---

## 5. Environment variable values overwritten on import

**Symptom.** After importing, the company code or monitored mailbox points at
values that are not yours.

**Cause.** Solution exports can carry environment variable **values** as well as
definitions.

**Status.** This package ships definitions only. You set every value yourself.
If you ever re-export this solution to move it onward, confirm the export does
not contain `environmentvariablevalues.json`.

---

## 6. The agent can report success that the data does not support

The agent summarises its own work in natural language, and that summary can
overstate what was written. A connector call reporting success only means the
call was accepted.

**What this means for you.** Treat connector success, flow success, and the
agent's own wording as *claims*, not evidence. The acceptance test in
`PPAC-INSTALL.md` Step 7 exists for this reason: compare the Dataverse line
count and quantities against the F&O order directly.

---

## 7. Large orders

Orders of roughly 100 lines or more are the least settled area.

Current behaviour on very large orders:

- Extraction, line creation, and line numbering are correct.
- Product validation may not resolve every line.
- When that happens the ERP preflight **refuses to create the order** and the
  header goes to Manual Review.

**This is fail-closed and is the intended safety behaviour** — no partial or
incorrect sales order is created. But it does mean a large order may need
manual attention.

**Recommendation.** Pilot with orders under 100 lines. If you process larger
orders, verify the first few against F&O line by line.

---

## 8. The same document can behave differently on different runs

Extraction, customer matching, and product validation are AI-driven, so the
same document can produce different results on different runs. The pipeline
normalises formatting and fails closed where a result cannot be trusted, but
the practical consequence is important:

> A single successful run is not proof the system is reliable. Run your
> acceptance test more than once, across several representative documents.
