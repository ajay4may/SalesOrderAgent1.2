# Sales Order Document Parsing — Customer Deployment Package

Version `1.0.1.0` · built 2026-10-05

This package installs an agent that reads sales-order documents (PDF, Word,
Excel, images, and plain-text email bodies), extracts the order and its lines,
validates the customer and products against Dynamics 365 Finance and
Operations, and creates the sales order in ERP.

---

## ⚠️ Read this before you install

Install the three units **in the order below**. The order is not a
convenience — each unit registers something the next one needs, and installing
out of order produces errors that look unrelated to the real cause.

| Order | Unit | How | Roughly |
|---|---|---|---|
| 1 | **Azure resources** | PowerShell script | 15–20 min |
| 2 | **Custom connector** | Manual import, Power Apps | 5 min |
| 3 | **Main solution** | Manual import, Power Apps + Power Platform admin centre | 30–45 min |

PowerShell is used for **Azure only**. Every Power Platform step is manual and
documented, so that a single failure stays isolated and diagnosable rather than
appearing as a total deployment failure.

---

## What you need before starting

| Requirement | Detail |
|---|---|
| Azure subscription | Contributor plus User Access Administrator on the target resource group |
| Azure resource group | Must already exist. The script does not create it. |
| Power Platform environment | With Dataverse, and System Administrator rights |
| Dynamics 365 F&O | Reachable from the environment, with a company (legal entity) code |
| Licensing | Copilot Studio capacity and Power Automate per the agent's use |
| Tools | Azure CLI, Azure Developer CLI (`azd`), PowerShell 7+ |

You will be asked for the Azure subscription, the existing resource group, and
the Power Platform environment URL. The package contains **no** supplier
subscription, tenant, environment, or mailbox values.

---

## Package contents

```
1-Azure/
  Install-Azure.ps1                       Run this
  AZURE-RESOURCES.md                      Every resource, setting and permission explained
  files/
    Install-Azure-Core.ps1                Implementation
    Azure/
      azure.yaml
      markitdown-converter-source.zip     Function application payload
      infrastructure/                     Bicep templates

2-Connector/
  SalesOrderMarkItDownConnector_1.0.1.1_managed.zip
  CONNECTOR-IMPORT.md          Import and connection creation

3-PowerPlatform/
  SalesOrderAgentProcessingTemplateV12_1.0.4.0_managed.zip
  PPAC-INSTALL.md              Import, connection references, app user, PPAC steps

QUICKSTART.md                  The short sequence, for experienced administrators
FAQ.md                         Common questions
KNOWN-ISSUES-AND-FIXES.md      Known issues and how to avoid them
Test-Readiness.ps1             Checks the installation and the Function key
YOUR-VALUES.md                 Written by the Azure installer with your values
CHECKSUMS.sha256
```

`YOUR-VALUES.md` does not exist until you run the Azure installer. It holds the
exact Function hostname and managed identity client ID to paste into Units 2
and 3, and deliberately contains no secrets.

Do not rearrange the `1-Azure/files` folder. The installer resolves its
artifacts by relative path and fails immediately if they move.

---

## The short version

1. Run `1-Azure/Install-Azure.ps1`. It writes `YOUR-VALUES.md`.
2. Copy a Function key from the Azure portal.
3. Import the connector solution, then create one connection using the Function
   host and key from `YOUR-VALUES.md`.
4. Import the main solution.
5. Bind **all ten** of its connection references. `PPAC-INSTALL.md` lists them.
6. Create the Dataverse application user for the Function's managed identity.
7. Set the environment variables.
8. Publish the agent.
9. Turn on the supporting flows, leaving the three automatic flows off.
10. Run `Test-Readiness.ps1` and fix everything it reports as FAIL.
11. Process one document end to end and confirm the result in Dataverse and in
    Finance and Operations **before** turning on the automatic flows.

See `QUICKSTART.md` for the same sequence with commands.

---

## What each unit installs

| Unit | Contents |
|---|---|
| 1 — Azure resources | Function app, storage, Application Insights, Log Analytics and managed identity, protected by a Function key |
| 2 — Connector | The MarkItDown custom connector, as its own managed solution |
| 3 — Main solution | The agent, 4 business skills, 11 flows, tables, 10 connection references and 7 environment variable definitions. No environment variable values, and all three automatic flows arrive stopped |

Step 8 is the acceptance test for your environment: creating the connection and
application user in your tenant, then processing one real document through to
Finance and Operations. Complete it before enabling the automatic flows.

---

## Two rules that matter more than the rest

**A connector action reporting success is not business success.** Always
confirm the Dataverse row reached a terminal status and that extracted JSON was
actually persisted.

**Leave the automatic flows off until you have verified one document.** They
ship stopped deliberately. Turning them on early means a failure arrives as a
stream of partially processed records instead of one inspectable result.
