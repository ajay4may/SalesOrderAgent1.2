# Azure Resources — What Gets Created and Why

Everything below is created by `Install-Azure.ps1` into the **existing**
resource group you nominate. Names use a deterministic token derived from the
subscription, resource group and environment name, so re-running the script
updates the same resources rather than creating duplicates.

---

## Resource inventory

| # | Resource | Type | Name pattern | Purpose |
|---|---|---|---|---|
| 1 | Managed identity | `Microsoft.ManagedIdentity/userAssignedIdentities` | `azid{token}` | The only credential the Function uses for Dataverse and Storage. No secrets. |
| 2 | Storage account | `Microsoft.Storage/storageAccounts` | `azst{token}` | Function deployment payload and runtime state |
| 3 | Blob container | `blobServices/containers` | `app-{token}` | Holds the deployed application package |
| 4 | Log Analytics workspace | `Microsoft.OperationalInsights/workspaces` | `azla{token}` | Telemetry store, 30-day retention |
| 5 | Application Insights | `Microsoft.Insights/components` | `azai{token}` | Function monitoring, workspace-based |
| 6 | App Service plan | `Microsoft.Web/serverfarms` | `azpl{token}` | Flex Consumption (`FC1`), Linux |
| 7 | Function app | `Microsoft.Web/sites` | `azfn{token}` | Runs the document converter and extractor |

---

## 1. User-assigned managed identity

The Function authenticates to Dataverse and Storage as this identity. There is
no client secret and no certificate anywhere in the package.

After the main solution import you create a **Dataverse application user** for
this identity and give it **one** security role,
`Sales Order MarkItDown Converter`.

> Do not assign System Administrator. The converter needs only the staging
> tables, and a broad grant makes a later security review harder than it needs
> to be.

## 2. Storage account

| Setting | Value | Why |
|---|---|---|
| SKU | `Standard_LRS` | Transient deployment and runtime data only |
| Kind | `StorageV2` | Required for Flex Consumption |
| `allowSharedKeyAccess` | **false** | Forces identity-based access; no account keys exist to leak |
| `defaultToOAuthAuthentication` | true | Entra ID by default |
| `allowBlobPublicAccess` | false | No anonymous access |
| `minimumTlsVersion` | TLS 1.2 | |
| Blob soft delete | 7 days | Recovery window for the deployment container |

## 3. Deployment container

Named `app-{token}`, private. The Function reads its application package from
here using the managed identity, not a connection string.

## 4. Log Analytics workspace

`PerGB2018`, 30-day retention. Raise retention if your organisation requires
longer diagnostic history.

## 5. Application Insights

Workspace-based, wired to the workspace above. Telemetry is authenticated with
the managed identity rather than an instrumentation key.

## 6. App Service plan — Flex Consumption

| Setting | Value |
|---|---|
| SKU | `FC1`, tier `FlexConsumption` |
| Platform | Linux |
| Always-ready instances | **1** (HTTP) |
| Instance memory | 2048 MB |
| Maximum instances | 20 |

**Why one always-ready instance:** document conversion is slow to cold start.
Without it the first document of the day can exceed the caller's timeout and
appear to fail. This is a deliberate, small, fixed cost.

## 7. Function app

| Setting | Value |
|---|---|
| Runtime | Python 3.12 |
| Identity | The user-assigned identity above |
| HTTPS only | true |
| FTPS | Disabled |
| Minimum TLS | 1.2 |
| App Service Authentication (Easy Auth) | **Disabled** |
| Function route | `POST /api/convert` |
| Authorisation | Function key (`x-functions-key`) |

### Application settings

| Setting | Value | Notes |
|---|---|---|
| `AZURE_CLIENT_ID` | identity client ID | **Only for a user-assigned identity.** A system-assigned identity must not have this set. |
| `AzureWebJobsStorage__credential` | `managedidentity` | No connection string |
| `AzureWebJobsStorage__clientId` | identity client ID | Selects the identity for storage bindings only |
| `AzureWebJobsStorage__blobServiceUri` / `queueServiceUri` / `tableServiceUri` | storage endpoints | |
| `APPLICATIONINSIGHTS_AUTHENTICATION_STRING` | `Authorization=AAD;ClientId=…` | Identity-based telemetry |
| `APPLICATIONINSIGHTS_CONNECTION_STRING` | from App Insights | |
| `DATAVERSE_URL` | your environment URL | You supply this |
| `MAX_FILE_BYTES` | `20971520` (20 MiB) | Upper bound on a single document |
| `MAX_MARKDOWN_CHARS` | `1000000` | Upper bound on converted text |

> `AzureWebJobsStorage__clientId` chooses the identity for **storage bindings**.
> It does **not** choose the identity used for Dataverse. That is
> `AZURE_CLIENT_ID`. Setting only the first is a silent misconfiguration that
> surfaces much later as a Dataverse permission error.

---

## Role assignments created

All are scoped to the resources above and granted to the managed identity.

| Role | Scope | Why |
|---|---|---|
| Storage Blob Data Owner | deployment container | Read the application package |
| Storage Blob Data Contributor | storage account | Runtime blob state |
| Storage Queue Data Contributor | storage account | Runtime queue state |
| Storage Table Data Contributor | storage account | Runtime table state |
| Monitoring Metrics Publisher | Application Insights | Publish telemetry as the identity |

Creating role assignments requires **User Access Administrator** (or Owner) on
the resource group. Contributor alone is not enough, and the failure appears as
a generic authorization error at the end of an otherwise successful run.

---

## Deployment behaviour worth knowing

**The Python payload must be built remotely.** The installer deploys with a
remote build so that `requirements.txt` is installed in the Function. A zip
deployed without a remote build produces an app with no dependencies: the
`/api/convert` route is never registered and every call returns **404** rather
than an error that points at the cause.

**Easy Auth is intentionally disabled.** Admission is controlled by the Function
key carried in the Power Platform connection. An unauthenticated call must
return **401**. If it returns 200 the Function is open; if it returns 404 the
application failed to start.

---

## What the script does not do

- It does not create the resource group.
- It does not import any Power Platform solution.
- It does not create the Power Platform connection.
- It does not create the Dataverse application user.
- It never writes a Function key to disk or to any log.

Those are deliberate, so that a failure is attributable to one platform.

---

## Verifying the Azure half

```powershell
# Expect 401 — the route exists and is protected.
Invoke-WebRequest -Uri "https://<function-host>/api/convert" `
                  -Method POST -Body '{}' -ContentType 'application/json'
```

| Response | Meaning |
|---|---|
| **401** | Correct. Deployed and protected. |
| 404 | Application failed to start — almost always a missing remote build |
| 200 | The Function is unprotected. Stop and investigate. |
