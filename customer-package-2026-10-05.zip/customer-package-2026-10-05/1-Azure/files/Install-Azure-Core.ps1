[CmdletBinding()]
param(
    [Parameter()]
    [string] $AzureSubscriptionId,

    [Parameter()]
    [string] $ResourceGroupName,

    [Parameter()]
    [string] $PowerPlatformEnvironmentUrl,

    [Parameter()]
    [ValidatePattern("^[a-zA-Z0-9-]{1,64}$")]
    [string] $AzdEnvironmentName = "sales-order-agent-v12",

    [Parameter()]
    [string] $DeploymentSettingsPath,

    [Parameter()]
    [switch] $ConfirmSubscription,

    [Parameter()]
    [switch] $PreflightOnly,

    [Parameter()]
    [switch] $AzureOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$SolutionVersion = "1.0.0.5"
$ConverterRoleName = "Sales Order MarkItDown Converter"
$ReleaseRoot = $PSScriptRoot
$AzureBundleRoot = Join-Path $ReleaseRoot "Azure"
$InfrastructureRoot = Join-Path $AzureBundleRoot "infrastructure"
$FunctionSourceArchive = Join-Path $AzureBundleRoot "markitdown-converter-source.zip"
$ManagedSolutionPath = Join-Path $ReleaseRoot "PowerPlatform\IMPORT_THIS_SalesOrderAgentProcessingTemplateV12_${SolutionVersion}_managed.zip"
$DeploymentDirectory = Join-Path $AzureBundleRoot ".deployment"
$DeploymentSourceDirectory = Join-Path $DeploymentDirectory "markitdown-converter"

function Write-Step {
    param([Parameter(Mandatory)][string] $Message)

    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Get-RequiredCommand {
    param([Parameter(Mandatory)][string] $Name)

    $command = Get-Command $Name -ErrorAction SilentlyContinue
    if (-not $command) {
        throw "Required command '$Name' is not installed or is not on PATH."
    }
    return $command.Source
}

function Invoke-External {
    param(
        [Parameter(Mandatory)][string] $FilePath,
        [Parameter(Mandatory)][string[]] $Arguments,
        [switch] $AllowFailure,
        [switch] $SuppressOutput
    )

    $output = & $FilePath @Arguments 2>&1
    $exitCode = $LASTEXITCODE
    $text = ($output | ForEach-Object { "$_" }) -join [Environment]::NewLine

    if ($exitCode -ne 0 -and -not $AllowFailure) {
        $safeText = if ($SuppressOutput) { "Output suppressed." } else { $text.Trim() }
        throw "'$FilePath $($Arguments -join ' ')' failed with exit code $exitCode. $safeText"
    }

    return [pscustomobject]@{
        ExitCode = $exitCode
        Output = $text.Trim()
    }
}

function Invoke-ExternalJson {
    param(
        [Parameter(Mandatory)][string] $FilePath,
        [Parameter(Mandatory)][string[]] $Arguments
    )

    $result = Invoke-External -FilePath $FilePath -Arguments $Arguments
    if ([string]::IsNullOrWhiteSpace($result.Output)) {
        throw "'$FilePath $($Arguments -join ' ')' returned no JSON output."
    }

    # Some Azure CLI installations emit warnings on stderr, for example the
    # 32-bit Python notice, which Invoke-External merges into the output.
    # Discard anything before the first JSON token.
    $lines = $result.Output -split "`r?`n"
    $start = 0
    while ($start -lt $lines.Count -and $lines[$start].TrimStart() -notmatch '^[\{\[]') {
        $start++
    }
    if ($start -ge $lines.Count) {
        throw "'$FilePath $($Arguments -join ' ')' returned no JSON output. $($result.Output)"
    }

    return ($lines[$start..($lines.Count - 1)] -join [Environment]::NewLine) | ConvertFrom-Json
}

function Normalize-PowerPlatformUrl {
    param([Parameter(Mandatory)][string] $Value)

    $candidate = $Value.Trim().TrimEnd("/")
    if ($candidate -notmatch "^[a-zA-Z][a-zA-Z0-9+.-]*://") {
        $candidate = "https://$candidate"
    }
    $uri = $null
    if (-not [uri]::TryCreate($candidate, [UriKind]::Absolute, [ref] $uri)) {
        throw "Power Platform environment URL '$Value' is not a valid absolute URL."
    }
    if ($uri.Scheme -ne "https") {
        throw "Power Platform environment URL must use HTTPS."
    }
    return $uri.AbsoluteUri.TrimEnd("/")
}

function Confirm-SelectedSubscription {
    param(
        [Parameter(Mandatory)][string] $SubscriptionName,
        [Parameter(Mandatory)][string] $SubscriptionId
    )

    if ($ConfirmSubscription) {
        return
    }

    Write-Host "Azure subscription: $SubscriptionName ($SubscriptionId)" -ForegroundColor Yellow
    $answer = Read-Host "Deploy to this subscription? Type YES to continue"
    if ($answer.Trim() -ine "YES") {
        throw "Subscription confirmation was not provided. No deployment was started."
    }
}

function Assert-ReleaseArtifacts {
    $requiredPaths = @(
        (Join-Path $InfrastructureRoot "main.bicep"),
        (Join-Path $InfrastructureRoot "resources.bicep"),
        (Join-Path $InfrastructureRoot "main.parameters.json"),
        (Join-Path $AzureBundleRoot "azure.yaml"),
        $FunctionSourceArchive
    )
    if (-not $AzureOnly) {
        $requiredPaths += $ManagedSolutionPath
    }

    foreach ($path in $requiredPaths) {
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            throw "Required release artifact is missing: $path"
        }
    }

    if ($DeploymentSettingsPath -and -not (Test-Path -LiteralPath $DeploymentSettingsPath -PathType Leaf)) {
        throw "Deployment settings file does not exist: $DeploymentSettingsPath"
    }
}

function Read-ZipText {
    param(
        [Parameter(Mandatory)][string] $ZipPath,
        [Parameter(Mandatory)][string] $EntryName
    )

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
    try {
        $entry = $archive.GetEntry($EntryName)
        if (-not $entry) {
            throw "Archive '$ZipPath' does not contain '$EntryName'."
        }
        $reader = [System.IO.StreamReader]::new($entry.Open())
        try {
            return $reader.ReadToEnd()
        }
        finally {
            $reader.Dispose()
        }
    }
    finally {
        $archive.Dispose()
    }
}

function Assert-MarkItDownOnlySource {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $forbiddenEntryPatterns = @(
        "content_understanding",
        "engines.py"
    )
    $forbiddenCodePatterns = @(
        "EXTRACTION_ENABLED",
        "EXTRACTION_STRATEGY",
        "CU_ENDPOINT",
        "CONTENT_UNDERSTANDING",
        "AZURE_OPENAI"
    )

    $archive = [System.IO.Compression.ZipFile]::OpenRead($FunctionSourceArchive)
    try {
        foreach ($entry in $archive.Entries) {
            $normalizedName = $entry.FullName.ToLowerInvariant()
            foreach ($pattern in $forbiddenEntryPatterns) {
                if ($normalizedName.Contains($pattern.ToLowerInvariant())) {
                    throw "Function source contains forbidden non-MarkItDown artifact '$($entry.FullName)'."
                }
            }

            if ($entry.FullName -notmatch "\.(py|json|txt)$") {
                continue
            }

            $reader = [System.IO.StreamReader]::new($entry.Open())
            try {
                $content = $reader.ReadToEnd()
            }
            finally {
                $reader.Dispose()
            }

            foreach ($pattern in $forbiddenCodePatterns) {
                if ($content.IndexOf($pattern, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
                    throw "Function source entry '$($entry.FullName)' contains forbidden setting '$pattern'."
                }
            }
        }
    }
    finally {
        $archive.Dispose()
    }
}

function Assert-SolutionPackage {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [System.IO.Compression.ZipFile]::OpenRead($ManagedSolutionPath)
    try {
        $environmentValueEntries = @(
            $archive.Entries |
                Where-Object {
                    $_.FullName -match "(?i)environmentvariablevalues\.json$"
                }
        )
        if ($environmentValueEntries.Count -gt 0) {
            throw "Managed solution contains target-specific environment-variable values."
        }

        $textParts = foreach ($entry in $archive.Entries) {
            if ($entry.FullName -notmatch "\.(xml|json|yml|yaml)$") {
                continue
            }
            $reader = [System.IO.StreamReader]::new($entry.Open())
            try {
                $reader.ReadToEnd()
            }
            finally {
                $reader.Dispose()
            }
        }
        $combined = $textParts -join "`n"
    }
    finally {
        $archive.Dispose()
    }

    $forbidden = @(
        "new_sharedcontentunderstanding_7a9f9",
        "shared_contentunderstanding",
        "aipod_salesorderdocumentparsingv12_BAXK1o",
        "SalesOrderDocumentParsing V1.2",
        "aipod_sharedwebcontentsv2_mkdn",
        "shared_webcontentsv2",
        "cr875_sharedmicrosoftcopilotstudio_db931",
        "shared_microsoftcopilotstudio",
        "FUNCTION_AUTH_CLIENT_ID",
        "FUNCTION_AUTH_AUDIENCE"
    )
    foreach ($value in $forbidden) {
        if ($combined.IndexOf($value, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
            throw "Managed solution contains forbidden component '$value'."
        }
    }

    foreach ($required in @(
        "aipod_salesorderagentv1.2_byW5hK",
        "aipod_podocumentparsererporderextraction",
        "aipod_sourceorderedrowcount",
        "get_staging_document_file_content",
        "LoadSalesOrderData",
        "LineCountMismatch",
        "DataverseLineCountMismatch",
        "ExtractionNoLineItems",
        "ExtractionEmpty",
        "ExactNameAccounts",
        "aipod_markitdownconverter",
        "shared_new-5fmarkitdown-20converter-5fa9d5d34217cb0e92",
        "x-functions-key",
        $ConverterRoleName,
        "<Version>$SolutionVersion</Version>"
    )) {
        if ($combined.IndexOf($required, [StringComparison]::OrdinalIgnoreCase) -lt 0) {
            throw "Managed solution is missing required release marker '$required'."
        }
    }

    if ($DeploymentSettingsPath) {
        $settingsText = Get-Content -LiteralPath $DeploymentSettingsPath -Raw
        if ($settingsText -match "(?i)contentunderstanding|shared_contentunderstanding") {
            throw "Deployment settings contain a Content Understanding binding."
        }
    }
}

function Ensure-AzureLogin {
    param(
        [Parameter(Mandatory)][string] $AzPath,
        [Parameter(Mandatory)][string] $SubscriptionId
    )

    $account = Invoke-External -FilePath $AzPath -Arguments @(
        "account", "show", "--output", "json", "--only-show-errors"
    ) -AllowFailure

    if ($account.ExitCode -ne 0) {
        Write-Host "Azure sign-in is required. A browser window may open." -ForegroundColor Yellow
        Invoke-External -FilePath $AzPath -Arguments @(
            "login", "--output", "none"
        ) | Out-Null
    }

    Invoke-External -FilePath $AzPath -Arguments @(
        "account", "set", "--subscription", $SubscriptionId
    ) | Out-Null

    $tokenProbe = Invoke-External -FilePath $AzPath -Arguments @(
        "account", "get-access-token",
        "--resource", "https://management.azure.com/",
        "--output", "none",
        "--only-show-errors"
    ) -AllowFailure -SuppressOutput
    if ($tokenProbe.ExitCode -ne 0) {
        Write-Host "Azure sign-in needs to be refreshed. A browser window may open." -ForegroundColor Yellow
        Invoke-External -FilePath $AzPath -Arguments @(
            "login", "--output", "none"
        ) | Out-Null
        Invoke-External -FilePath $AzPath -Arguments @(
            "account", "set", "--subscription", $SubscriptionId
        ) | Out-Null
    }

    # Deploying the Function package needs an App Service scoped token, which
    # is issued separately from the management token. Conditional access can
    # leave the management token valid while the App Service one requires a
    # fresh multi-factor prompt, which otherwise only surfaces much later as
    # AADSTS50078 in the middle of deployment.
    $appServiceProbe = Invoke-External -FilePath $AzPath -Arguments @(
        "account", "get-access-token",
        "--resource", "https://appservice.azure.com/",
        "--output", "none",
        "--only-show-errors"
    ) -AllowFailure -SuppressOutput
    if ($appServiceProbe.ExitCode -ne 0) {
        Write-Host "Azure App Service access needs a fresh sign-in. A browser window may open." -ForegroundColor Yellow
        Invoke-External -FilePath $AzPath -Arguments @(
            "login", "--scope", "https://appservice.azure.com/.default", "--output", "none"
        ) | Out-Null
        Invoke-External -FilePath $AzPath -Arguments @(
            "account", "set", "--subscription", $SubscriptionId
        ) | Out-Null
    }

    $selected = Invoke-ExternalJson -FilePath $AzPath -Arguments @(
        "account", "show",
        "--query", "{id:id,name:name,tenantId:tenantId}",
        "--output", "json",
        "--only-show-errors"
    )

    if ($selected.id -ne $SubscriptionId) {
        throw "Azure CLI selected subscription '$($selected.id)', not '$SubscriptionId'."
    }
    return $selected
}

function Assert-ExistingResourceGroup {
    param(
        [Parameter(Mandatory)][string] $AzPath,
        [Parameter(Mandatory)][string] $Name
    )

    $result = Invoke-External -FilePath $AzPath -Arguments @(
        "group", "show",
        "--name", $Name,
        "--query", "{name:name,location:location,id:id}",
        "--output", "json",
        "--only-show-errors"
    ) -AllowFailure
    if ($result.ExitCode -ne 0) {
        if ($result.Output -match "(?i)ResourceGroupNotFound|could not be found|was not found") {
            throw "Azure resource group '$Name' does not exist in subscription '$AzureSubscriptionId'. Create it first, then rerun this installer."
        }
        throw "Azure CLI could not verify resource group '$Name'. Resolve the Azure CLI error, then rerun this installer. $($result.Output)"
    }
    return $result.Output | ConvertFrom-Json
}

function Assert-RbacCapacity {
    param([Parameter(Mandatory)][string] $AzPath)

    $assignments = Invoke-ExternalJson -FilePath $AzPath -Arguments @(
        "role", "assignment", "list",
        "--all",
        "--fill-principal-name", "false",
        "--query", "[].id",
        "--output", "json",
        "--only-show-errors"
    )
    $count = @($assignments).Count
    $requiredAssignments = 5
    $limit = 5000
    if (($count + $requiredAssignments) -gt $limit) {
        throw "Azure RBAC capacity check failed: $count assignments exist and deployment needs up to $requiredAssignments more; subscription limit is $limit."
    }
    Write-Host "RBAC capacity: $count existing, up to $requiredAssignments planned, limit $limit."
}

function Assert-AzureRegionalCapacity {
    param(
        [Parameter(Mandatory)][string] $AzPath,
        [Parameter(Mandatory)][string] $Location
    )

    $normalizedLocation = $Location.ToLowerInvariant()
    $flexLocations = Invoke-External -FilePath $AzPath -Arguments @(
        "functionapp", "list-flexconsumption-locations",
        "--query", "[?name=='$normalizedLocation'].name",
        "--output", "tsv",
        "--only-show-errors"
    )
    $availableLocations = $flexLocations.Output -split "\r?\n"
    if ($availableLocations -notcontains $normalizedLocation) {
        throw "Azure Functions Flex Consumption is not available in resource-group location '$Location'."
    }

    $storageAccounts = Invoke-ExternalJson -FilePath $AzPath -Arguments @(
        "storage", "account", "list",
        "--query", "[?primaryLocation=='$normalizedLocation'].id",
        "--output", "json",
        "--only-show-errors"
    )
    $storageCount = @($storageAccounts).Count
    $storageLimit = 250
    if (($storageCount + 1) -gt $storageLimit) {
        throw "Regional storage-account capacity check failed: $storageCount accounts exist in '$Location' and the deployment needs one more; limit is $storageLimit."
    }
    Write-Host "Regional capacity: Flex Consumption available; $storageCount of $storageLimit storage accounts in '$Location'."
}

function Initialize-AzdEnvironment {
    param(
        [Parameter(Mandatory)][string] $AzdPath,
        [Parameter(Mandatory)][string] $AzureRoot,
        [Parameter(Mandatory)][string] $Location
    )

    Push-Location -LiteralPath $AzureRoot
    try {
        $select = Invoke-External -FilePath $AzdPath -Arguments @(
            "env", "select", $AzdEnvironmentName, "--no-prompt"
        ) -AllowFailure
        if ($select.ExitCode -ne 0) {
            Invoke-External -FilePath $AzdPath -Arguments @(
                "env", "new", $AzdEnvironmentName, "--no-prompt"
            ) | Out-Null
        }

        $values = [ordered]@{
            AZURE_SUBSCRIPTION_ID = $AzureSubscriptionId
            AZURE_RESOURCE_GROUP = $ResourceGroupName
            AZURE_LOCATION = $Location
            DATAVERSE_URL = $PowerPlatformEnvironmentUrl
            INSTANCE_MEMORY_MB = "2048"
            MAXIMUM_INSTANCE_COUNT = "20"
        }
        foreach ($entry in $values.GetEnumerator()) {
            Invoke-External -FilePath $AzdPath -Arguments @(
                "env", "set", $entry.Key, $entry.Value
            ) | Out-Null
        }
    }
    finally {
        Pop-Location
    }
}

function Test-FunctionResponding {
    <#
        Returns true when the Function is serving its route and enforcing the
        Function key, which is the 401 challenge. Used to decide whether an
        in-flight deployment already succeeded before retrying it.
    #>
    param([Parameter(Mandatory)][string] $FunctionAppName)

    $uri = "https://$FunctionAppName.azurewebsites.net/api/convert"
    try {
        $response = Invoke-WebRequest -Uri $uri -Method POST -Body "{}" `
            -ContentType "application/json" -TimeoutSec 30 -ErrorAction Stop
        return ($response.StatusCode -eq 401)
    }
    catch {
        $status = $null
        try { $status = [int] $_.Exception.Response.StatusCode } catch { }
        return ($status -eq 401)
    }
}

function Test-FunctionAppExists {
    <#
        Confirms a Function app actually exists in the resource group.
        Deliberately avoids a JMESPath tag filter: the embedded quoting does not
        survive being passed through az.cmd, which silently yields no match.
    #>
    param(
        [Parameter(Mandatory)][string] $AzPath,
        [Parameter(Mandatory)][string] $ResourceGroup,
        [Parameter(Mandatory)][string] $Name
    )

    $result = Invoke-External -FilePath $AzPath -Arguments @(
        "functionapp", "show",
        "--resource-group", $ResourceGroup,
        "--name", $Name,
        "--output", "none",
        "--only-show-errors"
    ) -AllowFailure
    return ($result.ExitCode -eq 0)
}

function Get-AzdValues {
    param(
        [Parameter(Mandatory)][string] $AzdPath,
        [Parameter(Mandatory)][string] $AzureRoot
    )

    Push-Location -LiteralPath $AzureRoot
    try {
        return Invoke-ExternalJson -FilePath $AzdPath -Arguments @(
            "env", "get-values", "--output", "json"
        )
    }
    finally {
        Pop-Location
    }
}

function Ensure-PacAuthentication {
    param([Parameter(Mandatory)][string] $PacPath)

    $profileName = "SalesOrderAutomation-$AzdEnvironmentName"
    $select = Invoke-External -FilePath $PacPath -Arguments @(
        "auth", "select", "--name", $profileName
    ) -AllowFailure
    if ($select.ExitCode -ne 0) {
        Write-Host "Power Platform sign-in is required. A browser window may open." -ForegroundColor Yellow
        Invoke-External -FilePath $PacPath -Arguments @(
            "auth", "create",
            "--environment", $PowerPlatformEnvironmentUrl,
            "--name", $profileName
        ) | Out-Null
    }

    $who = Invoke-External -FilePath $PacPath -Arguments @(
        "org", "who", "--environment", $PowerPlatformEnvironmentUrl
    )
    if ($who.Output.IndexOf($PowerPlatformEnvironmentUrl, [StringComparison]::OrdinalIgnoreCase) -lt 0) {
        Write-Warning "PAC authentication succeeded, but the environment URL was not present in 'pac org who' output. The import command still targets the explicit URL."
    }
}

function Import-PowerPlatformSolution {
    param([Parameter(Mandatory)][string] $PacPath)

    $arguments = @(
        "solution", "import",
        "--path", $ManagedSolutionPath,
        "--environment", $PowerPlatformEnvironmentUrl,
        "--publish-changes",
        "--async",
        "--max-async-wait-time", "60"
    )
    if ($DeploymentSettingsPath) {
        $arguments += @("--settings-file", (Resolve-Path -LiteralPath $DeploymentSettingsPath).Path)
    }

    Invoke-External -FilePath $PacPath -Arguments $arguments | Out-Null
}

function Get-DataverseAccessToken {
    param([Parameter(Mandatory)][string] $AzPath)

    $token = (Invoke-External -FilePath $AzPath -Arguments @(
        "account", "get-access-token",
        "--resource", $PowerPlatformEnvironmentUrl,
        "--query", "accessToken",
        "--output", "tsv",
        "--only-show-errors"
    ) -SuppressOutput).Output
    if ([string]::IsNullOrWhiteSpace($token)) {
        throw "Azure CLI did not return a Dataverse access token."
    }
    return $token
}

function Invoke-Dataverse {
    param(
        [Parameter(Mandatory)][ValidateSet("GET", "POST")][string] $Method,
        [Parameter(Mandatory)][string] $RelativePath,
        [Parameter(Mandatory)][string] $AccessToken,
        [object] $Body
    )

    $headers = @{
        Authorization = "Bearer $AccessToken"
        Accept = "application/json"
        "OData-MaxVersion" = "4.0"
        "OData-Version" = "4.0"
    }
    $parameters = @{
        Method = $Method
        Uri = "$PowerPlatformEnvironmentUrl/api/data/v9.2/$RelativePath"
        Headers = $headers
        ContentType = "application/json; charset=utf-8"
    }
    if ($null -ne $Body) {
        $parameters.Body = $Body | ConvertTo-Json -Depth 10 -Compress
    }
    return Invoke-RestMethod @parameters
}

function Ensure-DataverseApplicationUser {
    param(
        [Parameter(Mandatory)][string] $AccessToken,
        [Parameter(Mandatory)][guid] $IdentityClientId,
        [Parameter(Mandatory)][guid] $IdentityPrincipalId
    )

    $businessUnits = Invoke-Dataverse -Method GET -AccessToken $AccessToken -RelativePath (
        "businessunits?`$select=businessunitid,name&`$filter=parentbusinessunitid eq null"
    )
    if ($businessUnits.value.Count -ne 1) {
        throw "Expected one Dataverse root business unit, found $($businessUnits.value.Count)."
    }
    $businessUnitId = [guid] $businessUnits.value[0].businessunitid

    $users = Invoke-Dataverse -Method GET -AccessToken $AccessToken -RelativePath (
        "systemusers?`$select=systemuserid,applicationid&`$filter=applicationid eq $IdentityClientId"
    )
    if ($users.value.Count -gt 1) {
        throw "More than one Dataverse application user uses managed identity client ID '$IdentityClientId'."
    }

    if ($users.value.Count -eq 1) {
        $systemUserId = [guid] $users.value[0].systemuserid
        Write-Host "Reusing Dataverse application user '$systemUserId'."
    }
    else {
        $response = Invoke-WebRequest -Method POST `
            -Uri "$PowerPlatformEnvironmentUrl/api/data/v9.2/systemusers" `
            -Headers @{
                Authorization = "Bearer $AccessToken"
                Accept = "application/json"
                "OData-MaxVersion" = "4.0"
                "OData-Version" = "4.0"
                Prefer = "return=representation"
            } `
            -ContentType "application/json; charset=utf-8" `
            -Body (@{
                "businessunitid@odata.bind" = "/businessunits($businessUnitId)"
                applicationid = $IdentityClientId
                azureactivedirectoryobjectid = $IdentityPrincipalId
                accessmode = 4
                firstname = "Sales Order"
                lastname = "MarkItDown Converter"
            } | ConvertTo-Json -Compress)
        $created = $response.Content | ConvertFrom-Json
        $systemUserId = [guid] $created.systemuserid
        Write-Host "Created Dataverse application user '$systemUserId'."
    }

    $escapedRoleName = [uri]::EscapeDataString($ConverterRoleName.Replace("'", "''"))
    $roles = Invoke-Dataverse -Method GET -AccessToken $AccessToken -RelativePath (
        "roles?`$select=roleid,name&`$filter=name eq '$escapedRoleName' and _businessunitid_value eq $businessUnitId"
    )
    if ($roles.value.Count -ne 1) {
        throw "Required security role '$ConverterRoleName' was not found in the root business unit after solution import."
    }
    $roleId = [guid] $roles.value[0].roleid

    $assignedRoles = Invoke-Dataverse -Method GET -AccessToken $AccessToken -RelativePath (
        "systemusers($systemUserId)/systemuserroles_association?`$select=roleid&`$filter=roleid eq $roleId"
    )
    if ($assignedRoles.value.Count -eq 0) {
        Invoke-Dataverse -Method POST -AccessToken $AccessToken -RelativePath (
            "systemusers($systemUserId)/systemuserroles_association/`$ref"
        ) -Body @{
            "@odata.id" = "$PowerPlatformEnvironmentUrl/api/data/v9.2/roles($roleId)"
        } | Out-Null
        Write-Host "Assigned '$ConverterRoleName' to the Function managed identity application user."
    }
}

function Test-FunctionAuthentication {
    param([Parameter(Mandatory)][string] $FunctionUri)

    $curlPath = Get-RequiredCommand -Name "curl.exe"
    $status = (Invoke-External -FilePath $curlPath -Arguments @(
        "--silent",
        "--request", "POST",
        "--output", "NUL",
        "--write-out", "%{http_code}",
        "$($FunctionUri.TrimEnd('/'))/api/convert"
    )).Output
    if ($status -ne "401") {
        throw "Unauthenticated Function check returned HTTP $status; expected 401."
    }
    Write-Host "Function-key enforcement check returned HTTP 401 as required."
}

if (-not $AzureSubscriptionId) {
    $AzureSubscriptionId = (Read-Host "Azure subscription ID").Trim()
}
if (-not $AzureSubscriptionId) {
    throw "An Azure subscription ID is required."
}
if (-not $ResourceGroupName) {
    $ResourceGroupName = (Read-Host "Existing Azure resource-group name").Trim()
}
if (-not $ResourceGroupName) {
    throw "An existing Azure resource-group name is required."
}
if (-not $PowerPlatformEnvironmentUrl) {
    $PowerPlatformEnvironmentUrl = Read-Host "Power Platform environment URL"
}
$PowerPlatformEnvironmentUrl = Normalize-PowerPlatformUrl -Value $PowerPlatformEnvironmentUrl

Write-Step "Checking release artifacts and MarkItDown-only boundaries"
Assert-ReleaseArtifacts
Assert-MarkItDownOnlySource
if (-not $AzureOnly) {
    Assert-SolutionPackage
}

Write-Step "Checking required command-line tools"
$az = Get-RequiredCommand -Name "az"
$azd = Get-RequiredCommand -Name "azd"
$pac = if ($AzureOnly) { $null } else { Get-RequiredCommand -Name "pac" }
Get-RequiredCommand -Name "pwsh" | Out-Null

Write-Step "Validating Azure subscription and existing resource group"
$subscription = Ensure-AzureLogin -AzPath $az -SubscriptionId $AzureSubscriptionId
Confirm-SelectedSubscription -SubscriptionName $subscription.name -SubscriptionId $subscription.id
$resourceGroup = Assert-ExistingResourceGroup -AzPath $az -Name $ResourceGroupName
Assert-RbacCapacity -AzPath $az
Assert-AzureRegionalCapacity -AzPath $az -Location $resourceGroup.location
Write-Host "Resource group '$($resourceGroup.name)' exists in '$($resourceGroup.location)'."

if ($PreflightOnly) {
    Write-Host ""
    Write-Host "Preflight passed. No Azure resources or Power Platform components were changed." -ForegroundColor Green
    exit 0
}

Write-Step "Preparing the Function-key AZD environment"
Initialize-AzdEnvironment `
    -AzdPath $azd `
    -AzureRoot $AzureBundleRoot `
    -Location $resourceGroup.location

Write-Step "Preparing the MarkItDown deterministic Function deployment payload"
if (Test-Path -LiteralPath $DeploymentDirectory) {
    Remove-Item -LiteralPath $DeploymentDirectory -Recurse -Force
}
New-Item -ItemType Directory -Path $DeploymentSourceDirectory -Force | Out-Null
Expand-Archive -LiteralPath $FunctionSourceArchive -DestinationPath $DeploymentSourceDirectory -Force

try {
    Push-Location -LiteralPath $AzureBundleRoot
    try {
        Write-Step "Provisioning Azure resources in the existing resource group"
        Invoke-External -FilePath $azd -Arguments @(
            "provision", "--no-prompt"
        ) | Out-Null
    }
    finally {
        Pop-Location
    }

    # azd caches provision state per environment and will report
    # "There are no changes to provision" without deploying anything if the
    # resources were removed out of band. Its outputs are then stale, naming a
    # Function app that no longer exists. Treat the output as a hint and
    # confirm against Azure before relying on it.
    $functionAppName = (Get-AzdValues -AzdPath $azd -AzureRoot $AzureBundleRoot).SERVICE_API_NAME
    $exists = $functionAppName -and (Test-FunctionAppExists -AzPath $az -ResourceGroup $ResourceGroupName -Name $functionAppName)

    if (-not $exists) {
        Write-Host "    provisioning reported no changes but the Function app is absent; forcing a fresh provision"
        Push-Location -LiteralPath $AzureBundleRoot
        try {
            Invoke-External -FilePath $azd -Arguments @(
                "provision", "--no-prompt", "--no-state"
            ) | Out-Null
        }
        finally {
            Pop-Location
        }
        $functionAppName = (Get-AzdValues -AzdPath $azd -AzureRoot $AzureBundleRoot).SERVICE_API_NAME
        $exists = $functionAppName -and (Test-FunctionAppExists -AzPath $az -ResourceGroup $ResourceGroupName -Name $functionAppName)
    }

    if (-not $exists) {
        throw "Provisioning completed but Function app '$functionAppName' does not exist in resource group '$ResourceGroupName'. Resolve the provisioning failure before rerunning."
    }

    # The Function package is deployed directly rather than with 'azd deploy'.
    # azd resolves the target by matching both azd-service-name and
    # azd-env-name tags, so deploying into a resource group that was first
    # provisioned under a different environment name fails with
    # "unable to find a resource tagged with 'azd-service-name: api'" even
    # though the Function exists and is tagged correctly. Deploying by name
    # removes that coupling and the sensitivity to the installed azd version.
    Write-Step "Deploying the MarkItDown deterministic Function to $functionAppName"
    $deploymentPackage = Join-Path $DeploymentDirectory "markitdown-converter.zip"
    if (Test-Path -LiteralPath $deploymentPackage) {
        Remove-Item -LiteralPath $deploymentPackage -Force
    }
    Compress-Archive -Path (Join-Path $DeploymentSourceDirectory "*") -DestinationPath $deploymentPackage -Force

    # --build-remote is required. Without it the Python dependencies in
    # requirements.txt are never installed, the application fails to start, and
    # /api/convert returns 404 instead of the expected 401.
    #
    # The first attempts commonly fail for transient reasons that only occur
    # immediately after provisioning:
    #
    #   InaccessibleStorageException ... 403 - the storage account has shared
    #   key access disabled, so deployment authenticates with the managed
    #   identity whose role assignments were created moments earlier, and Azure
    #   role assignments take time to propagate.
    #
    #   NameResolutionError / getaddrinfo failed - the Function's SCM hostname
    #   is newly created and not yet resolvable in DNS.
    #
    #   DeploymentConflictException / 409 - the upload was already accepted and
    #   that deployment is still running.
    #
    # In the last two cases the deployment may already be succeeding, so after
    # a transient failure the Function is probed before deciding to retry.
    $transientDeploymentFailure =
        "InaccessibleStorageException|BlobUploadFailedException|403|" +
        "NameResolutionError|getaddrinfo|Max retries exceeded|ConnectionError|" +
        "DeploymentConflictException|409|502|503|Gateway"

    $deployArguments = @(
        "functionapp", "deployment", "source", "config-zip",
        "--resource-group", $ResourceGroupName,
        "--name", $functionAppName,
        "--src", $deploymentPackage,
        "--build-remote", "true"
    )
    $maximumAttempts = 10
    $deployed = $false
    for ($attempt = 1; $attempt -le $maximumAttempts; $attempt++) {
        $result = Invoke-External -FilePath $az -Arguments $deployArguments -AllowFailure
        if ($result.ExitCode -eq 0) {
            $deployed = $true
            break
        }

        # Sign-in problems are not transient. Retrying them wastes minutes and
        # buries the one line that tells the operator what to do.
        if ($result.Output -match "AADSTS|invalid_grant|InteractionRequired|multi-factor|ExpiredToken|AuthenticationFailed") {
            throw @"
Azure sign-in is not valid for deploying the Function package.

Deployment needs an App Service scoped token, which is issued separately from
the management token used earlier in this installer. Refresh it and rerun:

    az login --scope "https://appservice.azure.com/.default"

Original error:
$($result.Output)
"@
        }

        if ($result.Output -notmatch $transientDeploymentFailure -or $attempt -eq $maximumAttempts) {
            throw "Function deployment failed after $attempt attempt(s): $($result.Output)"
        }

        Write-Host ("    deployment endpoint is still settling; waiting 30 seconds ({0} of {1})" -f $attempt, ($maximumAttempts - 1))
        Start-Sleep -Seconds 30

        if (Test-FunctionResponding -FunctionAppName $functionAppName) {
            Write-Host "    the Function is serving requests; deployment completed."
            $deployed = $true
            break
        }
    }
    if (-not $deployed) {
        throw "Function deployment did not succeed."
    }
}
finally {
    if (Test-Path -LiteralPath $DeploymentDirectory) {
        Remove-Item -LiteralPath $DeploymentDirectory -Recurse -Force
    }
}

# Read the deployed app directly. JMESPath expressions containing brackets or
# parentheses do not survive being passed through az.cmd on Windows, so the
# full object is fetched and parsed here instead of using --query.
$functionApp = Invoke-ExternalJson -FilePath $az -Arguments @(
    "functionapp", "show",
    "--resource-group", $ResourceGroupName,
    "--name", $functionAppName,
    "--output", "json",
    "--only-show-errors"
)

$assignedIdentities = $null
if ($functionApp.PSObject.Properties['identity'] -and $functionApp.identity) {
    if ($functionApp.identity.PSObject.Properties['userAssignedIdentities']) {
        $assignedIdentities = $functionApp.identity.userAssignedIdentities
    }
}
if (-not $assignedIdentities) {
    throw "Function app '$functionAppName' has no user-assigned managed identity."
}
$identityResourceId = @($assignedIdentities.PSObject.Properties.Name)[0]
$identity = Invoke-ExternalJson -FilePath $az -Arguments @(
    "identity", "show",
    "--ids", $identityResourceId,
    "--output", "json",
    "--only-show-errors"
)

# Azure CLI versions differ: some flatten the site properties, others return
# the raw ARM shape with everything under 'properties'. Strict mode makes a
# missing property an error rather than a null, so test before reading.
function Get-FirstPropertyValue {
    param(
        [Parameter(Mandatory)] $Object,
        [Parameter(Mandatory)][string] $Name
    )
    if ($null -eq $Object) { return $null }
    if ($Object.PSObject.Properties[$Name]) { return $Object.$Name }
    if ($Object.PSObject.Properties['properties']) {
        $nested = $Object.properties
        if ($nested -and $nested.PSObject.Properties[$Name]) { return $nested.$Name }
    }
    return $null
}

$functionHostName = Get-FirstPropertyValue -Object $functionApp -Name 'defaultHostName'
if (-not $functionHostName) {
    throw "Could not determine the host name of Function app '$functionAppName'."
}
$identityClientId = Get-FirstPropertyValue -Object $identity -Name 'clientId'
$identityPrincipalId = Get-FirstPropertyValue -Object $identity -Name 'principalId'

# Derived from Azure, not from azd outputs, for the same reason the Function
# name is verified: azd can report success without having deployed anything.
$azdValues = [pscustomobject]@{
    SERVICE_API_URI                = "https://$functionHostName"
    FUNCTION_IDENTITY_CLIENT_ID    = $identityClientId
    FUNCTION_IDENTITY_PRINCIPAL_ID = $identityPrincipalId
}
foreach ($requiredValue in @(
    "SERVICE_API_URI",
    "FUNCTION_IDENTITY_CLIENT_ID",
    "FUNCTION_IDENTITY_PRINCIPAL_ID"
)) {
    if (-not $azdValues.$requiredValue) {
        throw "Could not read '$requiredValue' from the deployed Function app '$functionAppName'."
    }
}

if ($AzureOnly) {
    Write-Step "Checking Function-key authentication"
    Test-FunctionAuthentication -FunctionUri $azdValues.SERVICE_API_URI

    $functionUri = [uri] $azdValues.SERVICE_API_URI
    $resultPath = Join-Path $ReleaseRoot "Azure-Deployment-Result.txt"
    @(
        "Azure installation completed."
        "Function URL: $($azdValues.SERVICE_API_URI)"
        "Function hostname: $($functionUri.Host)"
        "Managed identity client ID: $($azdValues.FUNCTION_IDENTITY_CLIENT_ID)"
        "Managed identity principal ID: $($azdValues.FUNCTION_IDENTITY_PRINCIPAL_ID)"
        "Power Platform environment: $PowerPlatformEnvironmentUrl"
        ""
        "No Function key is stored in this file."
        "Next: follow 2-Connector\CONNECTOR-IMPORT.md, or Unit 2 of the Word installation guide."
    ) | Set-Content -LiteralPath $resultPath -Encoding utf8

    Write-Host ""
    Write-Host "Azure installation completed." -ForegroundColor Green
    Write-Host "Function URL: $($azdValues.SERVICE_API_URI)"
    Write-Host "Deployment details: $resultPath"
    Write-Host ""
    Write-Host "Next: import the connector - see 2-Connector\CONNECTOR-IMPORT.md" -ForegroundColor Yellow
    exit 0
}

Write-Step "Authenticating to Power Platform and importing solution $SolutionVersion"
Ensure-PacAuthentication -PacPath $pac
Import-PowerPlatformSolution -PacPath $pac

Write-Step "Creating the Dataverse managed-identity application user"
$dataverseToken = Get-DataverseAccessToken -AzPath $az
try {
    Ensure-DataverseApplicationUser `
        -AccessToken $dataverseToken `
        -IdentityClientId ([guid] $azdValues.FUNCTION_IDENTITY_CLIENT_ID) `
        -IdentityPrincipalId ([guid] $azdValues.FUNCTION_IDENTITY_PRINCIPAL_ID)
}
finally {
    $dataverseToken = $null
}

Write-Step "Running post-deployment validation"
Test-FunctionAuthentication -FunctionUri $azdValues.SERVICE_API_URI

Write-Host ""
Write-Host "Sales Order Automation deployment completed." -ForegroundColor Green
Write-Host "Function URL: $($azdValues.SERVICE_API_URI)"
Write-Host "Power Platform environment: $PowerPlatformEnvironmentUrl"
Write-Host ""
Write-Host "Create one MarkItDown Converter connection with the Function hostname and a Function key, bind unresolved connection references, and keep automatic processing stopped until controlled end-to-end verification passes." -ForegroundColor Yellow
