targetScope = 'subscription'

@minLength(1)
@maxLength(64)
@description('The azd environment name used to generate deterministic resource names.')
param environmentName string

@minLength(1)
@description('Existing Azure resource group that receives the deployment.')
param resourceGroupName string

@minLength(1)
@description('Azure region for all regional resources.')
param location string

@minLength(1)
@description('Dataverse environment URL, for example https://org.crm.dynamics.com.')
param dataverseUrl string

@allowed([
  512
  2048
  4096
])
@description('Flex Consumption instance memory in MB.')
param instanceMemoryMB int = 2048

@minValue(1)
@maxValue(1000)
@description('Maximum Flex Consumption instance count.')
param maximumInstanceCount int = 20

var resourceToken = toLower(uniqueString(subscription().id, resourceGroupName, location, environmentName))
var tags = {
  'azd-env-name': environmentName
  workload: 'sales-document-parsing'
  capability: 'markitdown-conversion-only'
}

resource targetResourceGroup 'Microsoft.Resources/resourceGroups@2024-03-01' existing = {
  name: resourceGroupName
}

module resources 'resources.bicep' = {
  name: 'sales-document-parsing-resources'
  scope: targetResourceGroup
  params: {
    name: 'salesdoc'
    environmentName: environmentName
    location: location
    resourceToken: resourceToken
    dataverseUrl: dataverseUrl
    instanceMemoryMB: instanceMemoryMB
    maximumInstanceCount: maximumInstanceCount
    tags: tags
  }
}

output AZURE_LOCATION string = location
output AZURE_RESOURCE_GROUP string = targetResourceGroup.name
output SERVICE_API_NAME string = resources.outputs.functionAppName
output SERVICE_API_URI string = resources.outputs.functionAppUri
output FUNCTION_IDENTITY_CLIENT_ID string = resources.outputs.functionIdentityClientId
output FUNCTION_IDENTITY_PRINCIPAL_ID string = resources.outputs.functionIdentityPrincipalId
output environment string = environmentName
